import { world,system } from '@minecraft/server';
import { ActionFormData,MessageFormData,ModalFormData } from '@minecraft/server-ui';
function ui(player) {
  let form = new ActionFormData()
  .title("text.ui.setting")
  .button("text.ui.skin_select")
  if(player.hasTag(`no_gameplayer`)){
    form = form
    .button("text.ui.juryoku_level")
    .button("text.ui.all_advancement")
  }
  form = form
  .button("text.ui.exit")
  form.show(player).then(test => {
    if (test.isCanceled) return;
    else if(player.hasTag(`no_gameplayer`)){
      switch (test.selection) {
          case 0:
            skin_ui(player);
            break;
          case 1:
            juryoku_lv_ui(player);
            break;
          case 2:
            all_tag_ui(player);
            break;
          default:
            break;
      }
    }else {
      switch (test.selection) {
          case 0:
            skin_ui(player);
            break;
          default:
            break;
      }
    }
  })
};
function skin_ui(player) {
  const form = new ActionFormData()
  .title("text.ui.skin_select")
  .button("text.ui.SkinCustom")
  .button("text.ui.SkinCustomSlim")
  .button("text.ui.back")
  form.show(player).then(test => {
      if (test.isCanceled) return;
      switch (test.selection) {
        case 0:
          player.triggerEvent(`SkinCustom`);
          runcmd(player,`clear @s[m=!c] skull 0 1`);
            break;
        case 1:
          player.triggerEvent(`SkinCustomSlim`);
          runcmd(player,`clear @s[m=!c] skull 0 1`);
            break;
        case 2:
          ui(player);
            break;
      }
  })
};
function juryoku_lv_ui(player) {
  let form = new ModalFormData()
  .title("text.ui.juryoku_level")
  .slider("Level",1,4,1,1);
  form.show(player).then(test => {
    if (test.isCanceled || !test.formValues) return;
    runcmd(player,`function tag/skill/juryoku_level${test.formValues[0]}`);
    runcmd(player,`scoreboard players set @s juryoku_lv ${test.formValues[0]-1}`);
    runcmd(player,`scoreboard players set @s default_juryoku_lv ${test.formValues[0]-1}`);
    runcmd(player,`clear @s[m=!c] skull 0 1`);
  })
};
function all_tag_ui(player) {
  let form = new MessageFormData()
  .title("text.ui.all_advancement")
  .body("text.ui.all_advancement2")
  .button1("text.ui.no")
  .button2("text.ui.yes")
  form.show(player).then(test => {
    if(test.selection){
      runcmd(player,`function tag/all_tag`);
      runcmd(player,`clear @s[m=!c] skull 0 1`);
    }
  })
};
function tyobuku(player) {
  let form = new ActionFormData()
  .title("text.tokusa.item0")
  .button("text.ui.back");
  const tyobuku_list = [
    {
      type: "nue",
      tag: player.hasTag(`tyobuku_nue`)
    },
    {
      type: "gama",
      tag: player.hasTag(`tyobuku_gama`)
    },
    {
      type: "orochi",
      tag: player.hasTag(`tyobuku_orochi`)
    },
    {
      type: "bansyo",
      tag: player.hasTag(`tyobuku_bansyo`)
    },
    {
      type: "datto",
      tag: player.hasTag(`tyobuku_datto`)
    },
    {
      type: "makora",
      tag: player.hasTag(`tyobuku_makora`) || !player.hasTag(`tyobuku_gama`)
    }
  ];
  const tyovuku = tyobuku_list.filter(value=>{
    if(!value.tag){
      form = form.button('text.tokusa.tyobuku.'+value.type);
      return value;
    }
  })
  form.show(player).then(test => {
    if (test.isCanceled || !test.selection) return;
      switch (tyovuku[test.selection-1].type) {
          case "nue":
            runcmd(player,`execute as @s[scores={juryoku=..299}] run tellraw @s {"rawtext":[{"translate":"text.juryoku_no_use"}]}`);
            runcmd(player,`execute as @s[scores={juryoku=300..}] run function skill/tokusa/tyobuku/nue`);
            break;
          case "gama":
            runcmd(player,`execute as @s[scores={juryoku=..199}] run tellraw @s {"rawtext":[{"translate":"text.juryoku_no_use"}]}`);
            runcmd(player,`execute as @s[scores={juryoku=200..}] run function skill/tokusa/tyobuku/gama`);
            break;
          case "orochi":
            runcmd(player,`execute as @s[scores={juryoku=..199}] run tellraw @s {"rawtext":[{"translate":"text.juryoku_no_use"}]}`);
            runcmd(player,`execute as @s[scores={juryoku=200..}] run function skill/tokusa/tyobuku/orochi`);
            break;
          case "bansyo":
            runcmd(player,`execute as @s[scores={juryoku=..499}] run tellraw @s {"rawtext":[{"translate":"text.juryoku_no_use"}]}`);
            runcmd(player,`execute as @s[scores={juryoku=500..}] run function skill/tokusa/tyobuku/bansyo`);
            break;
          case "datto":
            runcmd(player,`execute as @s[scores={juryoku=..49}] run tellraw @s {"rawtext":[{"translate":"text.juryoku_no_use"}]}`);
            runcmd(player,`execute as @s[scores={juryoku=50..}] run function skill/tokusa/tyobuku/datto`);
            break;
          case "makora":
            runcmd(player,`execute as @s[scores={juryoku=..699}] run tellraw @s {"rawtext":[{"translate":"text.juryoku_no_use"}]}`);
            runcmd(player,`execute as @s[scores={juryoku=700..}] run function skill/tokusa/tyobuku/makora`);
            break;
          default:
            break;
      }
  })
};
const jurei_list = [
  {
    id: "rai:tokyu_jurei",
    score_name: 'count_tokyu',
    name: "特級呪霊 Special Grade Cursed Spirit",
    power: 800,
    juryoku_lv: 0
  },
  {
    id: "rai:koryu_jurei",
    score_name: 'count_koryu',
    name: "虹龍 Rainbow Dragon",
    power: 200,
    juryoku_lv: 2
  },
  {
    id: "rai:one_eye_jurei",
    score_name: 'count_one_eye',
    name: "一つ目の呪霊 One Eye Cursed Spirit",
    power: 200,
    juryoku_lv: 2
  },
  {
    id: "rai:raichu_jurei",
    score_name: 'count_raichu',
    name: "ライチュウ Raichu",
    power: 200,
    juryoku_lv: 1
  },
  {
    id: "rai:flea_jurei",
    score_name: 'count_flea',
    name: "ノミの呪霊 Flea Cursed Spirit",
    power: 50,
    juryoku_lv: 1
  },
  {
    id: "rai:kiss_jurei",
    score_name: 'count_kiss',
    name: "チューしよ呪霊 Kiss Cursed Spirit",
    power: 50,
    juryoku_lv: 1
  },
  {
    id: "rai:worm_jurei",
    score_name: 'count_worm',
    name: "ワームの呪霊 Worm Cursed Spirit",
    power: 50,
    juryoku_lv: 0,
    projectile: "worm_jurei"
  },
  {
    id: "rai:daruma_jurei",
    score_name: 'count_daruma',
    name: "ダルマの呪霊 Daruma Cursed Spirit",
    power: 50,
    juryoku_lv: 1
  },
  {
    id: "rai:frog_jurei",
    score_name: 'count_frog',
    name: "カエルの呪霊 Frog Cursed Spirit",
    power: 10,
    juryoku_lv: 0
  },
  {
    id: "rai:churu_jurei",
    score_name: 'count_churu',
    name: "ちゅーる呪霊 Slurp Cursed Spirit",
    power: 10,
    juryoku_lv: 0
  },
  {
    id: "rai:mouth_jurei",
    score_name: 'count_mouth',
    name: "口の呪霊 Mouth Cursed Spirit",
    power: 10,
    juryoku_lv: 0
  },
  {
    id: "rai:mushroom_jurei",
    score_name: 'count_mushroom',
    name: "キノコの呪霊 Mushroom Cursed Spirit",
    power: 10,
    juryoku_lv: 0
  },
  {
    id: "rai:chuchu_jurei",
    score_name: 'count_chuchu',
    name: "ちゅうちゅう呪霊 Suck Cursed Spirit",
    power: 5,
    juryoku_lv: 0
  },
  {
    id: "rai:fish_jurei",
    score_name: 'count_fish',
    name: "魚の呪霊 Fish Cursed Spirit",
    power: 2,
    juryoku_lv: 0
  },
  {
    id: "rai:ray_jurei",
    score_name: 'count_ray',
    name: "エイの呪霊 Ray Cursed Spirit",
    power: 10,
    juryoku_lv: 0
  },
  {
    id: "rai:sheep_jurei",
    score_name: 'count_sheep',
    name: "羊の呪霊 Sheep Cursed Spirit",
    power: 10,
    juryoku_lv: 0
  },
  {
    id: "rai:squid_jurei",
    score_name: 'count_squid',
    name: "イカの呪霊 Squid Cursed Spirit",
    power: 2,
    juryoku_lv: 0,
    projectile: "squid_jurei"
  },
  {
    id: "rai:fly_head_jurei",
    score_name: 'count_fly_head',
    name: "蝿頭 Fly Head",
    power: 1,
    juryoku_lv: 0
  },
  {
    id: "rai:fly_head2_jurei",
    score_name: 'count_fly_head2',
    name: "高専の蝿頭 Technical College Fly Head",
    power: 1,
    juryoku_lv: 0
  }
];
const skiller_player_list = [
  {
    id: "rai:squid_jurei",
    score_name: 'count_squid',
    name: "イカの呪霊 Squid Cursed Spirit",
    juryoku_lv: 0,
    projectile: "squid_jurei"
  },
  {
    id: "rai:worm_jurei",
    score_name: 'count_worm',
    name: "ワームの呪霊 Worm Cursed Spirit",
    juryoku_lv: 0,
    projectile: "worm_jurei"
  },
  {
    id: "rai:daruma_jurei",
    score_name: 'count_daruma',
    name: "ダルマの呪霊 Daruma Cursed Spirit",
    juryoku_lv: 1
  }
];
const student_geto_jurei = [
  {
    id: "rai:kiss_jurei",
    count: 1
  },
  {
    id: "rai:kiss_jurei",
    count: 1
  },
  {
    id: "rai:one_eye_jurei",
    count: 1
  },
  {
    id: "rai:ray_jurei",
    count: 1
  },
  {
    id: "rai:sheep_jurei",
    count: 1
  },
  {
    id: "rai:koryu_jurei",
    count: 1
  },
  {
    id: "rai:worm_jurei",
    count: 1,
    event: "worm_jurei"
  },
  {
    id: "rai:worm_jurei",
    count: 1,
    event: "worm_jurei"
  },
  {
    id: "rai:squid_jurei",
    count: 10,
    event: "squid_jurei"
  },
  {
    id: "rai:squid_jurei",
    count: 7,
    event: "squid_jurei"
  },
  {
    id: "rai:squid_jurei",
    count: 5,
    event: "squid_jurei"
  },
  {
    id: "rai:squid_jurei",
    count: 3,
    event: "squid_jurei"
  },
  {
    id: "rai:daruma_jurei",
    count: 1,
    event: "daruma_jurei"
  }
];
function jurei_soujutsu(player,juryoku_power_up=0) {
  let form = new ActionFormData()
  .title(`text.jurei_soujutsu.form${juryoku_power_up}`)
  .button("text.ui.back");
  const count_jurei = jurei_list.filter(value=>{
    value.score = getScore(player,value.score_name);
    if(value.score > 0){
      form = form.button(`entity.${value.id}.name`);
      return value;
    }
  });
  if(juryoku_power_up < 2){
    form = form.button(`text.jurei_soujutsu.juryoku_power_up`);
  }
  form.show(player).then(test => {
    if (test.isCanceled || !test.selection) return;
    else if(juryoku_power_up < 2 && count_jurei.length+1 === test.selection){
      if(getScore(player,'juryoku') >= (juryoku_power_up+1)*300){
        jurei_soujutsu(player,juryoku_power_up+1);
      }else {
        runcmd(player,`tellraw @s {"rawtext":[{"translate":"text.juryoku_no_use"}]}`);
      }
    }
    else {
      const juryoku = (juryoku_power_up-count_jurei[test.selection-1].juryoku_lv)*300;
      if(getScore(player,'juryoku') >= juryoku){
        if(juryoku_power_up > 0){
          runcmd(player,`tag @s add cooltime2`);
          runcmd(player,`scoreboard players add @s cooltime2 20`);
          runcmd(player,`scoreboard players remove @s juryoku ${juryoku}`);
        }
        player_jurei_data.set(player.name,count_jurei[test.selection-1]);
        jurei_soujutsu_summon(player,count_jurei[test.selection-1],juryoku_power_up,true)
      }else {
        runcmd(player,`tellraw @s {"rawtext":[{"translate":"text.juryoku_no_use"}]}`);
      }
    }
  });
};
function jurei_soujutsu_summon(player,jurei_data,juryoku_power_up=0,jurei_soujutsu_form=false){
  const jurei_name = jurei_data.id.replace(/^rai:/,'');
  if(jurei_data.projectile){
    let num = jurei_data.juryoku_lv+juryoku_power_up;
    if(jurei_data.projectile === "worm_jurei" && player.hasTag(`on_ground`)){
      runcmd(player,`summon rai:worm_jurei ~~0.5~ ~ 0 worm_jurei_attack`);
      runcmd(player,`scoreboard players set @e[family=worm_jurei_attack,tag=!worm_jurei_attack] juryoku_lv ${num ? num : 0}`);
      runcmd(player,`tag @e[family=worm_jurei_attack,tag=!worm_jurei_attack] add "PL_${player.name}"`);
      runcmd(player,`execute if entity @s[tag=!jusoshi,tag=!jurei] run tag @e[family=worm_jurei_attack,tag=!worm_jurei_attack] add school_team`);
      runcmd(player,`tag @e[family=worm_jurei_attack] add worm_jurei_attack`);
    }else if(jurei_data.projectile === "squid_jurei" && jurei_data.score >= 10){
      num = num > 0 ? num+1 : "";
      runcmd(player,`tag @s add squid_jurei${num}`);
      runcmd(player,`tag @s add cooltime2`);
      runcmd(player,`scoreboard players add @s cooltime2 20`);
      runcmd(player,`scoreboard players add @s no_move 20`);
      runcmd(player,`scoreboard players remove @s ${jurei_data.score_name} 14`);
      jurei_data.score = jurei_data.score-14;
    }else {
      num = num > 0 ? num+1 : "";
      player.triggerEvent(jurei_data.projectile+num);
    }
    if(jurei_soujutsu_form){
      runcmd(player,`tellraw @s {"rawtext":[{"translate":"text.jurei_soujutsu.set"},{"translate":"entity.${jurei_data.id}.name"},{"translate":"text.jurei_soujutsu.summon"},{"text":"${jurei_data.score-1}"},{"translate":"text.jurei_soujutsu.count"}]}`);
    }
  }else {
    player.triggerEvent(`jurei_soujutsu_${jurei_name}`);
    //イベントを0tickで発生→run_commandでtagをつけるのには1tickかかる？ためここでtagを検知
    runcmd(player,`scoreboard players set @e[family=tame_entity,tag=!jurei_soujutsu_jurei,family=jurei_soujutsu_entity] juryoku_lv ${jurei_data.juryoku_lv+juryoku_power_up ? jurei_data.juryoku_lv+juryoku_power_up : 0}`);
    runcmd(player,`tag @e[family=tame_entity,tag=!jurei_soujutsu_jurei,family=jurei_soujutsu_entity] add jurei_soujutsu_jurei`);
    if(jurei_soujutsu_form){
      runcmd(player,`tellraw @s {"rawtext":[{"translate":"text.jurei_soujutsu.set"},{"translate":"entity.${jurei_data.id}.name"},{"translate":"text.jurei_soujutsu.summon"},{"text":"${jurei_data.score-1}"},{"translate":"text.jurei_soujutsu.count"}]}`);
    }
  }
  runcmd(player,`scoreboard players remove @s ${jurei_data.score_name} 1`);
}
function uzumaki(player) {
  let form = new ModalFormData()
  .title(`entity.rai:uzumaki.name`)
  const count_jurei = jurei_list.filter(value=>{
    value.score = getScore(player,value.score_name);
    if(value.score > 0){
      form = form.slider(value.name,0,value.score,1,0);
      return value;
    }
  });
  if(count_jurei.length === 0){
    runcmd(player,`tellraw @s {"rawtext":[{"translate":"text.jurei_soujutsu.uzumaki.no_power"}]}`);
    return;
  };
  form.show(player).then(test => {
    if (test.isCanceled || !test.formValues) return;
    let damage = 0;
    const cmd_list = [];
    count_jurei.forEach((value,index)=>{
      const jurei_count = test.formValues[index];
      if(jurei_count > 0){
        damage = damage + value.power*jurei_count;
        if(value.jutsushiki){
        }
        cmd_list.push(`scoreboard players remove @s ${value.score_name} ${jurei_count}`);
      }
    });
    damage = Math.round(damage/30);
    if(damage > 0){
      if(getScore(player,'juryoku') >= 200){
        runcmd(player,`playsound j.water @a ~~1~ 1 0.2`);
        runcmd(player,`tag @s add uzumaki_set`);
        runcmd(player,`tag @s add no_move`);
        runcmd(player,`inputpermission set @s movement disabled`);
        runcmd(player,`tag @s add cooltime2`);
        runcmd(player,`scoreboard players add @s cooltime2 35`);
        runcmd(player,`scoreboard players remove @s juryoku 200`);
        runcmd(player,`execute anchored eyes run summon rai:uzumaki_object ~~~ ~ 0`);
        runcmd(player,`scoreboard players set @e[type=rai:uzumaki_object,tag=!uzumaki_object] juryoku_lv ${damage ? (damage > 100 ? 100 : damage) : 0}`);
        runcmd(player,`tag @e[type=rai:uzumaki_object,tag=!uzumaki_object] add "PL_${player.name}"`);
        runcmd(player,`tag @e[type=rai:uzumaki_object,tag=!uzumaki_object] add uzumaki_object`);
        cmd_list.forEach((cmd)=>{
          runcmd(player,cmd);
        });
      }else {
        runcmd(player,`tellraw @s {"rawtext":[{"translate":"text.juryoku_no_use"}]}`);
      }
    }else {
      runcmd(player,`tellraw @s {"rawtext":[{"translate":"text.jurei_soujutsu.uzumaki.no_power"}]}`);
    }
  });
};
function loop(callback, tick) {
  system.runInterval(() => {
    callback()
  }, tick)
};
loop(() => {runcmd(world.getDimension('overworld'),'function tick40');},40);
loop(() => {runcmd(world.getDimension('overworld'),'function tick10');},10);
loop(() => {runcmd(world.getDimension('overworld'),'function tick2');},2);
const player_jurei_data = new Map();
world.beforeEvents.chatSend.subscribe(event => {
  const player = event.sender;
  event.cancel=true;
  let chat = event.message;
  if(chat === "逆さ"){
    system.run(() => {
      player.nameTag = player.nameTag === "Grumm" ? player.name : "Grumm"
    });
  }
  const { container } = player.getComponent('minecraft:inventory');
  const slot = container.getSlot(player.selectedSlot);
  const item = slot?.typeId;
  if(item !== "rai:smartphone" && player.hasTag(`jugon`)){
    const random = Math.random()*8;
    if(random < 1){
      runcmd(player,`tellraw @a {"rawtext":[{"text":"<${player.name}> "},{"translate":"text.jugon.salmon"}]}`);
    }else if(random < 1) {
      runcmd(player,`tellraw @a {"rawtext":[{"text":"<${player.name}> "},{"translate":"text.jugon.fish_flakes"}]}`);
    }else if(random < 2) {
      runcmd(player,`tellraw @a {"rawtext":[{"text":"<${player.name}> "},{"translate":"text.jugon.caviar"}]}`);
    }else if(random < 3) {
      runcmd(player,`tellraw @a {"rawtext":[{"text":"<${player.name}> "},{"translate":"text.jugon.spicy_cod_roe"}]}`);
    }else if(random < 4) {
      runcmd(player,`tellraw @a {"rawtext":[{"text":"<${player.name}> "},{"translate":"text.jugon.mustard_leaf"}]}`);
    }else if(random < 5) {
      runcmd(player,`tellraw @a {"rawtext":[{"text":"<${player.name}> "},{"translate":"text.jugon.salmon_roe"}]}`);
    }else if(random < 6) {
      runcmd(player,`tellraw @a {"rawtext":[{"text":"<${player.name}> "},{"translate":"text.jugon.tuna_mayo"}]}`);
    }else if(random < 7) {
      runcmd(player,`tellraw @a {"rawtext":[{"text":"<${player.name}> "},{"translate":"text.jugon.tuna"}]}`);
    }else {
      runcmd(player,`tellraw @a {"rawtext":[{"text":"<${player.name}> "},{"translate":"text.jugon.kelp"}]}`);
    }
  }else if(item !== "rai:smartphone" && player.hasTag(`raichu`)){
    let word = Math.round(chat.length/2);
    runcmd(player,`tellraw @a {"rawtext":[{"text":"<${player.name}> ${`ライ`.repeat(word)}"}]}`);
  }else if(item !== "rai:smartphone" && player.hasTag(`tokyu_jurei`)){
    const random = Math.random();
    if(random > 0.5){
      runcmd(player,`tellraw @a {"rawtext":[{"text":"<${player.name}> アハッ"}]}`);
    }else {
      runcmd(player,`tellraw @a {"rawtext":[{"text":"<${player.name}> ケタケタケタ"}]}`);
    }
  }else {
    chat = chat.replace(/\\/g,`\\\\`);
    chat = chat.replace(/"/g,'\\"');
    runcmd(player,`tellraw @a {"rawtext":[{"text":"<${player.name}> ${chat}"}]}`);
  }
});
system.afterEvents.scriptEventReceive.subscribe(eventData => {
    let { id ,sourceEntity:entity } = eventData;
    id = id.replace(/^j:/,'');
    if(id.match(/^tomonari_/)){
      id = id.replace(/^tomonari_/,'');
      runcmd(entity,`tag @s add no_tomonari_damage`);
      runcmd(entity,`execute at @e[r=50,type=${entity.typeId},tag=!no_tomonari_damage] run summon rai:tomonari`);
      runcmd(entity,`damage @e[r=50,type=${entity.typeId},tag=!no_tomonari_damage] 8 suicide entity @a[name="${id}"]`);
      runcmd(entity,`tag @s remove no_tomonari_damage`);
    }else {
      switch (id) {
        case 'tag_reset':
          entity.getTags().forEach(tag=>{entity.removeTag(tag);});
        break;
        case 'change_raichu':
          if(Math.random() < 0.2){
            runcmd(entity,`execute at @s run summon rai:raichu_jurei ~~~ ~ ~ ride "${entity.name}"`);
            runcmd(entity,`ride @s start_riding @e[type=rai:raichu_jurei,name="${entity.name}"]`);
            var juryoku_lv = getScore(entity,`juryoku_lv`);
            runcmd(entity,`scoreboard players set @e[type=rai:raichu_jurei,name="${entity.name}"] juryoku_lv ${juryoku_lv ? juryoku_lv : 0}`);
          }else {
            runcmd(entity,`tellraw @s {"rawtext":[{"translate":"text.raichu.no_change_raichu"}]}`);
            runcmd(entity,`function skill/reset_cooltime2`);
            runcmd(entity,`tag @s add cooltime2`);
            runcmd(entity,`scoreboard players add @s cooltime2 300`);
          }
        break;
        case 'fukuma_mizushi':
            runcmd(entity,`execute if entity @e[type=rai:fukuma_mizushi,name="${entity.name}"] run tag @s add remove_fukuma_mizushi`);
            runcmd(entity,`execute as @s[tag=remove_fukuma_mizushi] run event entity @e[type=rai:fukuma_mizushi,name="${entity.name}",tag=ryoiki_start] despawn`);
            runcmd(entity,`execute as @s[tag=!remove_fukuma_mizushi,scores={juryoku=800..},tag=!cooltime,tag=!cooltime2,tag=on_ground] run function skill/sukuna/ryoiki_tenkai`);
            runcmd(entity,`tag @s remove remove_fukuma_mizushi`);
        break;
        case 'fukuma_mizushi2':
            var juryoku_lv = getScore(entity,`juryoku_lv`);
            if(juryoku_lv > 0){
              runcmd(entity,`event entity @e[family=ryoiki_tenkai2,scores={juryoku_lv=..${juryoku_lv}},r=129] ryoiki_lose`);
            }
            runcmd(entity,`event entity @e[family=ryoiki_tenkai,family=!ryoiki_tenkai2,r=85] ryoiki_lose`);
            runcmd(entity,`summon rai:fukuma_mizushi ~~~ ~ 0 start "${entity.name ? entity.name : ""}"`);
            runcmd(entity,`execute as @s run function entity/ryoiki_tenkai/ryoiki_start2`);
        break;
        case 'kango_aneitei':
          runcmd(entity,`execute if entity @e[type=rai:kango_aneitei,name="${entity.name}"] run tag @s add remove_kango_aneitei`);
          runcmd(entity,`execute as @s[tag=remove_kango_aneitei] run event entity @e[type=rai:kango_aneitei,name="${entity.name}",tag=ryoiki_start] despawn`);
          runcmd(entity,`execute as @s[tag=!remove_kango_aneitei,scores={juryoku=600..},tag=!cooltime,tag=!cooltime2,tag=on_ground] run function skill/tokusa/ryoiki_tenkai`);
          runcmd(entity,`tag @s remove remove_kango_aneitei`);
        break;
        case 'kango_aneitei2':
          var juryoku_lv = getScore(entity,`juryoku_lv`);
          if(juryoku_lv > 0){
            runcmd(entity,`event entity @e[family=ryoiki_tenkai,family=!ryoiki_tenkai2,scores={juryoku_lv=..${juryoku_lv-1}},r=41] ryoiki_lose`);
          }
          runcmd(entity,`execute if entity @e[family=ryoiki_tenkai,scores={juryoku_lv=${juryoku_lv+1}..},r=41] run tag @s add remove_kango_aneitei`);
          runcmd(entity,`execute if entity @e[family=ryoiki_tenkai2,r=85] run tag @s add remove_kango_aneitei`);
          runcmd(entity,`tellraw @s[tag=remove_kango_aneitei] {"rawtext":[{"translate":"text.ryoiki_tenkai.ryoiki_lose"}]}`);
          runcmd(entity,`execute as @s[tag=remove_kango_aneitei] run function skill/tokusa/ryoiki_tenkai2`);
          runcmd(entity,`playsound note.bass @s[tag=remove_kango_aneitei] ~~1~`);
          runcmd(entity,`execute if entity @e[family=ryoiki_tenkai,family=!ryoiki_tenkai2,scores={juryoku_lv=${juryoku_lv}},r=41] run summon rai:kango_aneitei ~~~ ~ 0 ryoiki_draw "${entity.name ? entity.name : ""}"`);
          runcmd(entity,`event entity @e[family=ryoiki_tenkai,family=!ryoiki_tenkai2,scores={juryoku_lv=${juryoku_lv}},r=41] ryoiki_draw`);
          runcmd(entity,`execute as @s[tag=!remove_kango_aneitei] unless entity @e[family=ryoiki_tenkai,family=!ryoiki_tenkai2,scores={juryoku_lv=${juryoku_lv}},r=41] run summon rai:kango_aneitei ~~~ ~ 0 start "${entity.name ? entity.name : ""}"`);
          runcmd(entity,`execute as @s[tag=!remove_kango_aneitei] run function entity/ryoiki_tenkai/ryoiki_start`);
          runcmd(entity,`tag @s remove remove_kango_aneitei`);
        break;
        case 'muryo_kusho':
          var juryoku = entity.hasTag(`rikugan`) ? 150 : 900;
          runcmd(entity,`execute if entity @e[type=rai:muryo_kusho,name="${entity.name}"] run tag @s add remove_muryo_kusho`);
          runcmd(entity,`execute as @s[tag=remove_muryo_kusho] run event entity @e[type=rai:muryo_kusho,name="${entity.name}",tag=ryoiki_start] despawn`);
          runcmd(entity,`execute as @s[tag=!remove_muryo_kusho,scores={juryoku=${juryoku}..},tag=!cooltime,tag=!cooltime2,tag=on_ground] run function skill/mukagen/ryoiki_tenkai`);
          runcmd(entity,`tag @s remove remove_muryo_kusho`);
        break;
        case 'muryo_kusho2':
          var juryoku_lv = getScore(entity,`juryoku_lv`);
          if(juryoku_lv > 0){
            runcmd(entity,`event entity @e[family=ryoiki_tenkai,family=!ryoiki_tenkai2,scores={juryoku_lv=..${juryoku_lv-1}},r=41] ryoiki_lose`);
          }
          runcmd(entity,`execute if entity @e[family=ryoiki_tenkai,scores={juryoku_lv=${juryoku_lv+1}..},r=41] run tag @s add remove_muryo_kusho`);
          runcmd(entity,`execute if entity @e[family=ryoiki_tenkai2,r=85] run tag @s add remove_muryo_kusho`);
          runcmd(entity,`tellraw @s[tag=remove_muryo_kusho] {"rawtext":[{"translate":"text.ryoiki_tenkai.ryoiki_lose"}]}`);
          runcmd(entity,`execute as @s[tag=remove_muryo_kusho] run function skill/mukagen/ryoiki_tenkai2`);
          runcmd(entity,`playsound note.bass @s[tag=remove_muryo_kusho] ~~1~`);
          runcmd(entity,`execute if entity @e[family=ryoiki_tenkai,family=!ryoiki_tenkai2,scores={juryoku_lv=${juryoku_lv}},r=41] run summon rai:muryo_kusho ~~~ ~ 0 ryoiki_draw "${entity.name ? entity.name : ""}"`);
          runcmd(entity,`event entity @e[family=ryoiki_tenkai,family=!ryoiki_tenkai2,scores={juryoku_lv=${juryoku_lv}},r=41] ryoiki_draw`);
          runcmd(entity,`execute as @s[tag=!remove_muryo_kusho] unless entity @e[family=ryoiki_tenkai,family=!ryoiki_tenkai2,scores={juryoku_lv=${juryoku_lv}},r=41] run summon rai:muryo_kusho ~~~ ~ 0 start "${entity.name ? entity.name : ""}"`);
          runcmd(entity,`execute as @s[tag=!remove_muryo_kusho] run function entity/ryoiki_tenkai/ryoiki_start`);
          runcmd(entity,`tag @s remove remove_muryo_kusho`);
        break;
        case 'change_sukuna':
          var random = Math.random();
          if(random < 0.2){
            runcmd(entity,`execute at @s run summon rai:sukuna ~~~ ~ ~ ride "${entity.name}"`);
            runcmd(entity,`ride @s start_riding @e[type=rai:sukuna,name="${entity.name}"]`);
            var score = getScore(entity,`sukuna_finger`);
            if(score > 1)runcmd(entity,`event entity @e[type=rai:sukuna,name="${entity.name}"] sukuna_finger${score}`);
          }else if(random < 0.8){
            runcmd(entity,`tellraw @s {"rawtext":[{"translate":"text.itadori.no_change_sukuna"}]}`);
            runcmd(entity,`function skill/reset_cooltime2`);
            runcmd(entity,`tag @s add cooltime2`);
            runcmd(entity,`scoreboard players add @s cooltime2 300`);
          }else {
            runcmd(entity,`tellraw @s {"rawtext":[{"translate":"text.itadori.no_change_sukuna2"}]}`);
            runcmd(entity,`function skill/reset_cooltime2`);
            runcmd(entity,`tag @s add cooltime2`);
            runcmd(entity,`scoreboard players add @s cooltime2 500`);
          }
        break;
        case 'sukuna_finger':
          var score = getScore(entity,`sukuna_finger`);
          if(score > 0)runcmd(entity,`function tag/itadori/sukuna_finger/sukuna_finger${score}`);
        break;
        case 'tyobuku_form':
          runcmd(entity,`execute unless entity @e[tag=tyobuku,tag=tokusa_shikigami,tag="PL_${entity.name}"] run scriptevent j:tyobuku_form2`);
          runcmd(entity,`execute if entity @e[tag=tyobuku,tag=tokusa_shikigami,tag="PL_${entity.name}"] run tellraw @s {"rawtext":[{"translate":"text.tokusa.no_tyobuku_summon"}]}`);
          runcmd(entity,`execute if entity @e[tag=tyobuku,tag=tokusa_shikigami,tag="PL_${entity.name}"] run playsound note.bass @s ~~1~`);
        break;
        case 'tyobuku_form2':
          tyobuku(entity);
        break;
        case 'kanzashi':
          runcmd(entity,`execute if entity @e[family=nail,tag="PL_${entity.name}"] run tag @s add kanzashi_test`);
          runcmd(entity,`execute if entity @e[tag="kanzashi_${entity.name}"] run tag @s add kanzashi_test`);
          runcmd(entity,`execute as @s[tag=kanzashi_test] run function skill/surei/kanzashi`);
          runcmd(entity,`tag @s remove kanzashi_test`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=0}] run damage @e[tag=!pvp,family=!damage,tag="kanzashi_${entity.name}",r=32] 8 entity_explosion entity @s`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=1}] run damage @e[tag=!pvp,family=!damage,tag="kanzashi_${entity.name}",r=32] 10 entity_explosion entity @s`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=2}] run damage @e[tag=!pvp,family=!damage,tag="kanzashi_${entity.name}",r=32] 12 entity_explosion entity @s`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=3}] run damage @e[tag=!pvp,family=!damage,tag="kanzashi_${entity.name}",r=32] 15 entity_explosion entity @s`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=0}] at @e[family=nail,tag="PL_${entity.name}"] run damage @e[tag=!pvp,family=!damage,tag=!"PL_${entity.name}",name=!"${entity.name}",r=3] 8 entity_explosion entity @s`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=1}] at @e[family=nail,tag="PL_${entity.name}"] run damage @e[tag=!pvp,family=!damage,tag=!"PL_${entity.name}",name=!"${entity.name}",r=3] 10 entity_explosion entity @s`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=2}] at @e[family=nail,tag="PL_${entity.name}"] run damage @e[tag=!pvp,family=!damage,tag=!"PL_${entity.name}",name=!"${entity.name}",r=3] 12 entity_explosion entity @s`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=3}] at @e[family=nail,tag="PL_${entity.name}"] run damage @e[tag=!pvp,family=!damage,tag=!"PL_${entity.name}",name=!"${entity.name}",r=3] 15 entity_explosion entity @s`);
          runcmd(entity,`tag @e remove "kanzashi_${entity.name}"`);
          runcmd(entity,`event entity @e[family=nail,tag="PL_${entity.name}"] despawn2`);
        break;
        case 'tomonari':
          runcmd(entity,`execute unless entity @e[tag="tomonari_${entity.name}"] run tellraw @s {"rawtext":[{"translate":"text.surei.no_tomonari"}]}`);
          runcmd(entity,`execute unless entity @e[tag="tomonari_${entity.name}"] run playsound note.bass @s ~~1~`);
          runcmd(entity,`execute if entity @e[tag="tomonari_${entity.name}"] run function skill/surei/tomonari2`);
        break;
        case 'attack_tomonari':
          runcmd(entity,`execute at @e[tag="tomonari_${entity.name}"] run summon rai:tomonari`);
          runcmd(entity,`execute if entity @e[tag="tomonari_${entity.name}"] run tellraw @s {"rawtext":[{"translate":"text.surei.tomonari2"},{"selector":"@e[tag=\\"tomonari_${entity.name}\\"]"}]}`);
          runcmd(entity,`execute as @e[tag="tomonari_${entity.name}",type=!player] run scriptevent "j:tomonari_${entity.name}"`);
          runcmd(entity,`damage @e[tag="tomonari_${entity.name}"] 15 suicide entity @s`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=0}] run damage @e[tag="tomonari_${entity.name}",type=!player] 15 suicide entity @s`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=1}] run damage @e[tag="tomonari_${entity.name}",type=!player] 20 suicide entity @s`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=2}] run damage @e[tag="tomonari_${entity.name}",type=!player] 25 suicide entity @s`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=3..}] run damage @e[tag="tomonari_${entity.name}",type=!player] 30 suicide entity @s`);
          runcmd(entity,`effect @e[tag="tomonari_${entity.name}"] slowness 2 3 true`);
          runcmd(entity,`execute at @e[tag="tomonari_${entity.name}"] run playsound random.explode @a ~~~`);
          runcmd(entity,`execute at @e[tag="tomonari_${entity.name}"] run playsound random.anvil_use @a ~~~ `);
          runcmd(entity,`tag @e[tag="tomonari_${entity.name}"] remove "tomonari_${entity.name}"`);
        break;
        case 'ryoiki_murasaki':
          runcmd(entity,`execute as @s[tag=ryoiki_tenkai_set] run scoreboard players remove @e[name="${entity.name ? entity.name : ""}",type=rai:muryo_kusho,c=1] despawn 600`);
        break;
        case 'aka':
          var juryoku_lv = getScore(entity,`juryoku_lv`);
          runcmd(entity,`execute anchored eyes run summon rai:knockback ^^^3 ~ ~ aka${juryoku_lv+1} "${entity.name ? entity.name : ""}"`);
          runcmd(entity,`execute as @s[tag=ryoiki_tenkai_set] run tag @e[family=aka,tag=!aka_set] add ryoiki_hit`);
          runcmd(entity,`execute as @s[tag=ryoiki_tenkai_set] run scoreboard players remove @e[name="${entity.name ? entity.name : ""}",type=rai:muryo_kusho,c=1] despawn 300`);
          runcmd(entity,`tag @e[family=aka,tag=!aka_set] add aka_set`);
        break;
        case 'ao':
          var juryoku_lv = getScore(entity,`juryoku_lv`);
          runcmd(entity,`execute anchored eyes run summon rai:knockback ^^^9 ~ ~ ao${juryoku_lv+1} "${entity.name ? entity.name : ""}"`);
          runcmd(entity,`execute as @s[tag=ryoiki_tenkai_set] run tag @e[family=ao,tag=!ao_set] add ryoiki_hit`);
          runcmd(entity,`tag @e[family=ao,tag=!ao_set] add ao_set`);
        break;
        case 'ao_stop':
          runcmd(entity,`event entity @e[type=rai:knockback,tag=ao_entity,name="${entity.name}"] despawn`);
        break;
        case 'player_ao_tp':
          var {x, y, z} = entity.getViewDirection();
          entity.applyKnockback(x, z, 8, y*3);
        break;
        case 'sekkin':
          var {x, y, z} = entity.getViewDirection();
          if(entity.typeId === "minecraft:player"){
            entity.applyKnockback(x, z, 5, 1.5*y+0.3);
          }else {
            if(Math.random() > 0.3){
              entity.applyKnockback(x, z, 4, 2*y);
            }else {
              entity.applyKnockback(x, z, 4, 1.5);
            }
          }
        break;
        case 'shikigami_sekkin':
          var {x, y, z} = entity.getViewDirection();
          if(Math.random() > 0.3){
            entity.applyKnockback(x, z, 2.5, y);
          }else {
            entity.applyKnockback(x, z, 2.5, 1.5);
          }
        break;
        case 'sekkin_slowness':
          var {x, y, z} = entity.getViewDirection();
          entity.applyKnockback(x, z, 1, 0.5*y+0.1);
        break;
        case 'change_triceratops':
          runcmd(entity,`execute at @s run summon rai:panda_triceratops ~~~ ~ ~ ride "${entity.name}"`);
          runcmd(entity,`ride @s start_riding @e[type=rai:panda_triceratops,name="${entity.name}"]`);
          var juryoku_lv = getScore(entity,`juryoku_lv`);
          runcmd(entity,`scoreboard players set @e[type=rai:panda_triceratops,name="${entity.name}"] juryoku_lv ${juryoku_lv ? juryoku_lv : 0}`);
        break;
        case 'megumi_sword':
          var {x, z} = entity.getViewDirection();
          entity.applyKnockback(x, z, 6, 0.3);
        break;
        case 'tozama':
          var {x, z} = entity.getViewDirection();
          entity.applyKnockback(x, z, 2, 0.1);
        break;
        case 'split_soul_sword':
          var {x, y, z} = entity.getViewDirection();
          if(entity.hasTag(`fushiguro_touji`)){
            entity.applyKnockback(x, z, 5, y*3);
          }else {
            entity.applyKnockback(x, z, 4, 0.2);
          }
        break;
        case 'amanosakahoko':
          var {x, y, z} = entity.getViewDirection();
          if(entity.hasTag(`fushiguro_touji`)){
            entity.applyKnockback(x, z, 3, y*3);
          }else {
            entity.applyKnockback(x, z, 2.5, 0.2);
          }
        break;
        case 'bakuten':
          var {x, z} = entity.getViewDirection();
          entity.applyKnockback(x, z, -4.5, 0.4);
        break;
        case 'bakuten_slowness':
          var {x, z} = entity.getViewDirection();
          entity.applyKnockback(x, z, -0.75, 0.2);
        break;
        case 'died':
          var tag = entity.getTags();
          //tokusa
          runcmd(entity,`execute as @e[tag=tokusa_shikigami,tag="PL_${entity.name}",family=tokusa_shikigami] at @s run function entity/tokusa/shikigami_destroy`);
          runcmd(entity,`ride @e[tag=tokusa_shikigami,tag="PL_${entity.name}",family=tokusa_shikigami,family=orochi] evict_riders`);
          runcmd(entity,`tp @e[tag=tokusa_shikigami,tag="PL_${entity.name}",family=tokusa_shikigami] ~ 1000 ~`);
          runcmd(entity,`event entity @e[tag=tokusa_shikigami,tag="PL_${entity.name}",family=tokusa_shikigami] despawn`);
          //surei
          runcmd(entity,`tag @e[tag="tomonari_${entity.name}"] remove "tomonari_${entity.name}"`);
          //jurei_soujutsu
          runcmd(entity,`tp @e[tag=jurei_soujutsu_jurei,tag="PL_${entity.name}"] ~ 1000 ~`);
          runcmd(entity,`event entity @e[tag=jurei_soujutsu_jurei,tag="PL_${entity.name}"] despawn`);
          runcmd(entity,`event entity @e[type=rai:uzumaki_object,tag="PL_${entity.name}"] despawn`);
          runcmd(entity,`event entity @e[name="${entity.name}",family=ryoiki_tenkai] despawn`);
          tag.forEach(tag=>{
            if(tag.startsWith("kanzashi_") || tag.startsWith("tomonari_")){
              entity.removeTag(tag);
            }
          });
        break;
        case 'setup':
          runcmd(entity,`event entity @e[name="${entity.name}",family=ryoiki_tenkai] despawn`);
        break;
        case 'shikigami_kaijo':
          if(entity.hasTag(`tokusa_shikigami`) && !entity.hasTag(`ride`)){
            runcmd(entity,`function entity/tokusa/shikigami_destroy`);
          }
          runcmd(entity,`event entity @s despawn`);
        break;
        case 'jutsushiki_kaijo':
          runcmd(entity,`execute at @e[family=shikigami,tag="PL_${entity.name}"] run function entity/tokusa/shikigami_destroy`);
          runcmd(entity,`event entity @e[family=shikigami,tag="PL_${entity.name}"] despawn`);
        break;
        case 'sekibaku':
          runcmd(entity,`effect @e[r=5,family=!damage,name=!"${entity.nameTag}",tag=!"PL_${entity.nameTag}"] slowness 1 4 true`);
        break;
        case 'senketsu':
          runcmd(entity,`tag @s add senketsu_set`);
          for (let i = 0; i < 50; i++) {
            runcmd(entity,`execute anchored eyes run particle minecraft:obsidian_glow_dust_particle ^^^${i*1.5}`);
            runcmd(entity,`execute anchored eyes positioned ^^^${i*1.5} run tag @e[family=!damage,r=2,tag=!senketsu_set] add damage_target`);
          }
          var juryoku_lv = getScore(entity,`juryoku_lv`);
          var damage = juryoku_lv === 3 ? 30 : juryoku_lv === 2 ? 24 : juryoku_lv === 1 ? 19 : 15;
          if(entity.typeId === "minecraft:player"){
            runcmd(entity,`damage @a[tag=!pvp,tag=damage_target] ${damage} entity_attack entity @s`);
          }else {
            runcmd(entity,`damage @a[tag=damage_target] ${damage} entity_attack entity @s`);
          }
          runcmd(entity,`damage @e[tag=damage_target,type=!player] ${damage*2} entity_attack entity @s`);
          runcmd(entity,`tag @e remove damage_target`);
          runcmd(entity,`tag @s remove senketsu_set`);
        break;
        case 'jurei_soujutsu_form':
          jurei_soujutsu(entity);
        break;
        case 'jurei_soujutsu_form2':
          var jurei_id = player_jurei_data.get(entity.name);
          if(jurei_id){
            var count_jurei = jurei_id.score_name;
            jurei_id.score = getScore(entity,count_jurei);
            if(jurei_id.score > 0){
              jurei_soujutsu_summon(entity,jurei_id)
            }else {
              jurei_soujutsu(entity);
            }
          }else {
            jurei_soujutsu(entity);
          }
        break;
        case 'uzumaki_form':
          uzumaki(entity);
        break;
        case 'jurei_soujutsu_skill':
          var item_num = getScore(entity,`item_num`);
          if(item_num < 4){
            return;
          }
          var jurei_id = skiller_player_list[item_num-4]
          var count_jurei = jurei_id.score_name;
          jurei_id.score = getScore(entity,count_jurei);
          if(jurei_id.score > 0){
            jurei_soujutsu_summon(entity,jurei_id)
          }
        break;
        case 'uzumaki':
          runcmd(entity,`execute unless entity @e[tag=uzumaki_object,tag="PL_${entity.name}"] run tag @s remove uzumaki_set`);
          runcmd(entity,`execute if entity @e[tag=uzumaki_object,tag="PL_${entity.name}"] run scriptevent j:uzumaki_shoot`);
        break;
        case 'uzumaki_shoot':
          runcmd(entity,`tag @s remove uzumaki_set`);
          runcmd(entity,`tag @s remove no_move`);
          runcmd(entity,`inputpermission set @s movement enabled`);
          runcmd(entity,`playsound random.explode @a ~~1~ 0.9 1.3`);
          runcmd(entity,`playsound random.explode @a ~~1~ 0.8 1.2`);
          runcmd(entity,`playsound random.explode @a ~~1~ 0.7 1.1`);
          runcmd(entity,`playsound random.explode @a ~~1~ 0.6 1`);
          runcmd(entity,`tag @s add cooltime2`);
          runcmd(entity,`scoreboard players add @s cooltime2 40`);
          entity.triggerEvent(`uzumaki`);
          runcmd(entity,`scoreboard players operation @e[family=uzumaki,tag=!uzumaki_entity] juryoku_lv = @e[type=rai:uzumaki_object,tag="PL_${entity.name}"] juryoku_lv`);
          runcmd(entity,`tag @e[family=uzumaki,tag=!uzumaki_entity] add "PL_${entity.name}"`);
          runcmd(entity,`tag @e[family=uzumaki,tag=!uzumaki_entity] add uzumaki_entity`);
          runcmd(entity,`event entity @e[type=rai:uzumaki_object,tag="PL_${entity.name}"] despawn`);
        break;
        case 'ao_tp':
          if(entity.nameTag !== ""){
            runcmd(entity,`execute at @a[name="${entity.nameTag}"] anchored eyes run tp ^^^9`);
          }
          var entities = entity.dimension.getEntities({tags: ["ao_test"]});
          if(!entities[0]){
            return;
          }
          entities.forEach(entity2=>{
            var y = ((entity.location.y-1.5)-entity2.location.y);
            y = y > 4 ? 4 : y;
            if(entity2.typeId === "minecraft:player"){
              entity2.applyKnockback(entity.location.x-entity2.location.x, entity.location.z-entity2.location.z, 1, y*0.5);
            }else {
              entity2.applyKnockback(entity.location.x-entity2.location.x, entity.location.z-entity2.location.z, 2, y*0.5);
            }
            entity2.removeTag(`ao_test`);
          });
        break;
        case 'ao_damage':
          var juryoku_lv = getScore(entity,`juryoku_lv`);
          switch (juryoku_lv) {
            case 0:
              runcmd(entity,`damage @a[r=5,name=!"${entity.nameTag}",tag=!pvp] 6 entity_explosion entity @s`);
              runcmd(entity,`damage @e[r=5,type=!player,tag=!"PL_${entity.nameTag}"] 6 entity_explosion entity @s`);
              break;
            case 1:
              runcmd(entity,`damage @a[r=5,name=!"${entity.nameTag}",tag=!pvp] 7 entity_explosion entity @s`);
              runcmd(entity,`damage @e[r=5,type=!player,tag=!"PL_${entity.nameTag}"] 7 entity_explosion entity @s`);
              break;
            case 2:
              runcmd(entity,`damage @a[r=5,name=!"${entity.nameTag}",tag=!pvp] 9 entity_explosion entity @s`);
              runcmd(entity,`damage @e[r=5,type=!player,tag=!"PL_${entity.nameTag}"] 9 entity_explosion entity @s`);
              break;
            case 3:
              runcmd(entity,`damage @a[r=5,name=!"${entity.nameTag}",tag=!pvp] 12 entity_explosion entity @s`);
              runcmd(entity,`damage @e[r=5,type=!player,tag=!"PL_${entity.nameTag}"] 12 entity_explosion entity @s`);
              break;
          }
        break;
        case 'ao_tp2':
          var entities = entity.dimension.getEntities({tags: ["ao_test2"]});
          if(!entities[0]){
            return;
          }
          var juryoku_lv = getScore(entity,`juryoku_lv`);
          runcmd(entity,`execute anchored eyes positioned ^^^10 run tag @e[r=10,tag=!ao_,tag=!no_gameplayer,family=!damage,type=!item,type=!falling_block] add damage_target`);
          if(entity.typeId === "minecraft:player"){
            switch (juryoku_lv) {
              case 0:
                runcmd(entity,`damage @a[tag=damage_target,name=!"${entity.nameTag}",tag=!pvp] 4 entity_explosion entity @s`);
                runcmd(entity,`damage @e[tag=damage_target,type=!player,tag=!"PL_${entity.nameTag}"] 4 entity_explosion entity @s`);
                break;
              case 1:
                runcmd(entity,`damage @a[tag=damage_target,name=!"${entity.nameTag}",tag=!pvp] 5 entity_explosion entity @s`);
                runcmd(entity,`damage @e[tag=damage_target,type=!player,tag=!"PL_${entity.nameTag}"] 5 entity_explosion entity @s`);
                break;
              case 2:
                runcmd(entity,`damage @a[tag=damage_target,name=!"${entity.nameTag}",tag=!pvp] 6 entity_explosion entity @s`);
                runcmd(entity,`damage @e[tag=damage_target,type=!player,tag=!"PL_${entity.nameTag}"] 6 entity_explosion entity @s`);
                break;
              case 3:
                runcmd(entity,`damage @a[tag=damage_target,name=!"${entity.nameTag}",tag=!pvp] 8 entity_explosion entity @s`);
                runcmd(entity,`damage @e[tag=damage_target,type=!player,tag=!"PL_${entity.nameTag}"] 8 entity_explosion entity @s`);
                break;
            }
          }else {
            switch (juryoku_lv) {
              case 0:
                runcmd(entity,`damage @e[tag=damage_target] 6 entity_explosion entity @s`);
                break;
              case 1:
                runcmd(entity,`damage @e[tag=damage_target] 7 entity_explosion entity @s`);
                break;
              case 2:
                runcmd(entity,`damage @e[tag=damage_target] 9 entity_explosion entity @s`);
                break;
              case 3:
                runcmd(entity,`damage @e[tag=damage_target] 12 entity_explosion entity @s`);
                break;
            }
          }
          entities.forEach(entity2=>{
            var y = (entity.location.y-entity2.location.y);
            y = y > 3 ? 3 : y;
            entity2.applyKnockback((entity.location.x-entity2.location.x), (entity.location.z-entity2.location.z), 10-y/2, y);
            entity2.removeTag(`ao_test2`);
          });
          runcmd(entity,`tag @e remove damage_target`);
        break;
        case 'aka_knockback':
          var juryoku_lv = getScore(entity,`juryoku_lv`);
          runcmd(entity,`tag @e[tag=!aka_entity,family=!damage,type=!item,type=!falling_block,r=6] add damage_target`);
          if(entity.hasTag(`mob_attack`)){
            switch (juryoku_lv) {
              case 0:
                runcmd(entity,`damage @a[tag=damage_target] 10 entity_explosion entity @s`);
                break;
              case 1:
                runcmd(entity,`damage @a[tag=damage_target] 12 entity_explosion entity @s`);
                break;
              case 2:
                runcmd(entity,`damage @a[tag=damage_target] 16 entity_explosion entity @s`);
                break;
              case 3:
                runcmd(entity,`damage @a[tag=damage_target] 20 entity_explosion entity @s`);
                break;
            }
          }else {
            switch (juryoku_lv) {
              case 0:
                runcmd(entity,`damage @a[tag=damage_target,name=!"${entity.nameTag}",tag=!pvp] 10 entity_explosion entity @s`);
                break;
              case 1:
                runcmd(entity,`damage @a[tag=damage_target,name=!"${entity.nameTag}",tag=!pvp] 12 entity_explosion entity @s`);
                break;
              case 2:
                runcmd(entity,`damage @a[tag=damage_target,name=!"${entity.nameTag}",tag=!pvp] 16 entity_explosion entity @s`);
                break;
              case 3:
                runcmd(entity,`damage @a[tag=damage_target,name=!"${entity.nameTag}",tag=!pvp] 20 entity_explosion entity @s`);
                break;
            }
          }
          runcmd(entity,`tag @e remove damage_target`);
          var {x, y, z} = entity.getViewDirection();
          var entities = entity.dimension.getEntities({tags: ["aka_knockback"]});
          if(!entities[0]){
            return;
          }
          entities.forEach(entity2=>{
            if(!entity2.typeId !== "minecraft:player" || entity2.name !== entity.nameTag){
              entity2.applyKnockback(x, z, 4, y+0.2);
              entity2.removeTag(`aka_knockback`);
            }
          });
        break;
        case 'otiro':
          entity.applyKnockback(0, 0, -30, -30);
        break;
        case 'buttobe':
          var {x, y, z} = entity.getViewDirection();
          var entities = entity.dimension.getEntities({tags: ["buttobe_attack"]});
          if(!entities[0]){
            return;
          }
          entities.forEach(entity2=>{
            if(!entity2.typeId !== "minecraft:player" || entity2.name !== entity.nameTag){
              entity2.applyKnockback(x, z, 20, y*2.5+2);
              entity2.removeTag(`buttobe_attack`);
            }
          });
        break;
        case 'shikigami_player_look':
          if(entity.nameTag){
            runcmd(entity,`execute rotated as "${entity.nameTag.replace(/^PL_/,'')}" run tp ~~~ ~ 0`);
          }else {
            var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
            if(PL) {
              runcmd(entity,`execute rotated as "${PL}" run tp ~~~ ~ 0`);
            }
          }
        break;
        case 'bansyo_mizu':
          var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
          if(entity.hasTag(`fushiguro_shikigami`)) {
            runcmd(entity,`execute rotated ~ 0 positioned ^^^5 run tag @e[type=!type:fushiguro,tag=!fushiguro_shikigami,family=!damage,type=!falling_block,r=10] add bansyo_mizu_attack`);
          }else if(PL !== ""){
            if(entity.hasTag(`tyobuku`)){
              runcmd(entity,`execute rotated ~ 0 positioned ^^^5 run tag @e[tag=!tyobuku,family=!damage,type=!falling_block,r=10] add bansyo_mizu_attack`);
            }else {
              runcmd(entity,`execute rotated ~ 0 positioned ^^^5 run tag @e[name=!"${PL}",tag=!"PL_${PL}",family=!damage,type=!falling_block,r=10] add bansyo_mizu_attack`);
              runcmd(entity,`execute rotated ~ 0 positioned ^^^5 run tag @e[tag="PL_${PL}",tag=tyobuku,r=10] add bansyo_mizu_attack`);
              runcmd(entity,`tag @a[tag=pvp] remove bansyo_mizu_attack`);
            }
          }
          runcmd(entity,`scriptevent j:bansyo_mizu_attack`);
        break;
        case 'bansyo_mizu_attack':
          var juryoku_lv = getScore(entity,`juryoku_lv`)+1;
          var {x, y, z} = entity.getViewDirection();
          var entities = entity.dimension.getEntities({tags: ["bansyo_mizu_attack"]});
          if(!entities[0]){
            return;
          }
          entities.forEach(entity2=>{
            entity2.applyKnockback(x, z, 20*(juryoku_lv/4), y/1.5+1);
            entity2.removeTag(`bansyo_mizu_attack`);
          });
        break;
        case 'uzumaki_entity':
          var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
          var juryoku_lv = getScore(entity,`juryoku_lv`);
          if(PL != ""){
            runcmd(entity,`damage @a[tag=!pvp,tag=!uzumaki_entity,name=!"${PL}",r=5] ${juryoku_lv} entity_attack entity @s`);
          }else {
            runcmd(entity,`damage @a[tag=!uzumaki_entity,name=!"${PL}",r=5] ${juryoku_lv} entity_attack entity @s`);
          }
          runcmd(entity,`damage @e[type=!player,tag=!uzumaki_entity,tag=!"PL_${PL}",r=5] ${juryoku_lv*4} entity_attack entity @s`);
        break;
        case 'uzumaki_explode':
          var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
          var juryoku_lv = getScore(entity,`juryoku_lv`);
          if(PL != ""){
            runcmd(entity,`damage @e[tag=!pvp,tag=!uzumaki_entity,name=!"${PL}",r=8] ${juryoku_lv} entity_attack entity @s`);
          }else {
            runcmd(entity,`damage @e[type=!player,tag=!uzumaki_entity,tag=!"PL_${PL}",r=8] ${juryoku_lv*4} entity_attack entity @s`);
          }
          if(juryoku_lv < 25){
            runcmd(entity,`summon rai:block_explode ~~~ ~ ~ explode4`);
          }else if(juryoku_lv < 50){
            runcmd(entity,`summon rai:block_explode ~~~ ~ ~ explode4`);
            runcmd(entity,`summon rai:block_explode ~~~ ~ ~ explode4`);
          }else if(juryoku_lv < 75){
            runcmd(entity,`summon rai:block_explode ~~~ ~ ~ explode5`);
            runcmd(entity,`summon rai:block_explode ~~~ ~ ~ explode5`);
          }else {
            runcmd(entity,`summon rai:block_explode ~~~ ~ ~ explode7`);
            runcmd(entity,`summon rai:block_explode ~~~ ~ ~ explode7`);
            runcmd(entity,`summon rai:block_explode ~~~ ~ ~ explode7`);
          }
        break;
        case 'geto_jurei_summon':
          var juryoku_lv = getScore(entity,`juryoku_lv`);
          var jurei = student_geto_jurei[random_integer(0,student_geto_jurei.length-1)];
          if(jurei.event){
            if(jurei.event === "squid_jurei"){
              runcmd(entity,`tag @s add squid_jurei`);
              runcmd(entity,`tag @s add cooltime2`);
              runcmd(entity,`scoreboard players set @s cooltime2 ${jurei.count}`);
            }else if(jurei.event === "worm_jurei"){
              runcmd(entity,`summon rai:worm_jurei ~~0.5~ ~ 0 worm_jurei_attack`);
              runcmd(entity,`scoreboard players set @e[family=worm_jurei_attack,tag=!worm_jurei_attack] juryoku_lv ${juryoku_lv ? juryoku_lv : 0}`);
              runcmd(entity,`execute as @s[type=rai:student_geto] run tag @e[family=worm_jurei_attack,tag=!worm_jurei_attack] add school_team`);
              runcmd(entity,`tag @e[family=worm_jurei_attack,tag=!worm_jurei_attack] add geto_jurei_soujutsu`);
              runcmd(entity,`tag @e[family=worm_jurei_attack] add worm_jurei_attack`);
            }else if(jurei.event === "daruma_jurei"){
              entity.triggerEvent(`jurei_soujutsu_daruma_jurei`);
            }
          }else {
            for (let i = 0; i < jurei.count; i++) {
              var randomPos = 0;
              while (1.5 > randomPos && randomPos > -1.5) {
                randomPos = (Math.random()-Math.random())*4;
              }
              runcmd(entity,`summon ${jurei.id} ^${randomPos}^^ ~ 0 geto_jurei_soujutsu`);
              runcmd(entity,`summon rai:particle ^${randomPos}^^ ~ 0 jurei_summon`);
            }
            runcmd(entity,`execute as @s[type=rai:student_geto] run tag @e[family=geto_jurei_soujutsu,tag=!geto_jurei_soujutsu] add school_team`);
            runcmd(entity,`execute as @s[tag=player_target] run tag @e[family=geto_jurei_soujutsu,tag=!geto_jurei_soujutsu] add geto_jurei_soujutsu_player`);
            runcmd(entity,`scoreboard players set @e[family=geto_jurei_soujutsu,tag=!geto_jurei_soujutsu] juryoku_lv ${juryoku_lv ? juryoku_lv : 0}`);
            runcmd(entity,`tag @e[family=geto_jurei_soujutsu,tag=!geto_jurei_soujutsu] add geto_jurei_soujutsu`);
          }
        break;
        case 'squid_jurei':
          entity.triggerEvent(`squid_jurei`);
          if(entity.typeId === "minecraft:player"){
            runcmd(entity,`tag @e[family=squid_jurei,tag=!squid_jurei] add "PL_${entity.name}"`);
            runcmd(entity,`tag @e[family=squid_jurei,tag=!squid_jurei] add squid_jurei`);
          }
        break;
        case 'squid_jurei2':
          entity.triggerEvent(`squid_jurei2`);
          if(entity.typeId === "minecraft:player"){
            runcmd(entity,`tag @e[family=squid_jurei,tag=!squid_jurei] add "PL_${entity.name}"`);
            runcmd(entity,`tag @e[family=squid_jurei,tag=!squid_jurei] add squid_jurei`);
          }
        break;
        case 'squid_jurei3':
          entity.triggerEvent(`squid_jurei3`);
          if(entity.typeId === "minecraft:player"){
            runcmd(entity,`tag @e[family=squid_jurei,tag=!squid_jurei] add "PL_${entity.name}"`);
            runcmd(entity,`tag @e[family=squid_jurei,tag=!squid_jurei] add squid_jurei`);
          }
        break;
        case 'squid_jurei4':
          entity.triggerEvent(`squid_jurei4`);
          if(entity.typeId === "minecraft:player"){
            runcmd(entity,`tag @e[family=squid_jurei,tag=!squid_jurei] add "PL_${entity.name}"`);
            runcmd(entity,`tag @e[family=squid_jurei,tag=!squid_jurei] add squid_jurei`);
          }
        break;
        case 'jurei_soujutsu_projectile_set':
          if(entity.hasTag(`mob_attack`)){
            runcmd(entity,`execute rotated as @e[type=rai:student_geto,c=1] run summon rai:particle ^^^-5 ~ ~ jurei_summon_3`);
          }else {
            var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
            runcmd(entity,`execute rotated as @a[name="${PL}"] run summon rai:particle ^^^-5 ~ ~ jurei_summon_3`);
          }
        break;
        case 'worm_jurei_attack':
          var score_test = getScore(entity,`score_test`);
          if(score_test > 8){
            return;
          }
          var juryoku_lv = getScore(entity,`juryoku_lv`);
          runcmd(entity,`tp @s[tag=!projectile_set] ^^^1.5 true`);
          runcmd(entity,`playsound random.explode @a ~~~`);
          if(entity.hasTag(`geto_jurei_soujutsu`)){
            runcmd(entity,`damage @e[r=2.5,type=!rai:student_geto,family=!damage] ${juryoku_lv === 3 ? 20 : juryoku_lv === 2 ? 15 : juryoku_lv === 1 ? 12 : 10} entity_attack entity @s`);
          }else {
            var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
            runcmd(entity,`damage @e[r=2.5,tag=!"PL_${PL}",name=!"${PL}",family=!damage,tag=!pvp] ${juryoku_lv === 3 ? 20 : juryoku_lv === 2 ? 15 : juryoku_lv === 1 ? 12 : 10} entity_attack entity @s`);
          }
          runcmd(entity,`scoreboard players add @s score_test 1`);
        break;
        case 'worm_jurei_up':
          var score_test = getScore(entity,`score_test`);
          if(score_test > 10){
            return;
          }
          var juryoku_lv = getScore(entity,`juryoku_lv`);
          var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
          var damage = juryoku_lv === 3 ? 20 : juryoku_lv === 2 ? 15 : juryoku_lv === 1 ? 12 : 10;
          runcmd(entity,`playsound random.explode @a ~~${score_test}~`);
          runcmd(entity,`execute positioned ~~${score_test}~ run damage @e[r=4,tag=!"PL_${PL}",name=!"${PL}",family=!damage,tag=!pvp] ${damage} entity_attack entity @s`);
          runcmd(entity,`scoreboard players add @s score_test 3`);
        break;
        case 'fuga':
          var PL = entity.name;
          var juryoku_lv = getScore(entity,`juryoku_lv`);
          var no_damage_selector = `family=!damage,type=!falling_block,tag=!fukuma_mizushi_sukuna,tag=!no_player,tag=!ryoiki_tenkai_set,tag=!no_gameplayer,name=!"${entity.nameTag}"`;
          switch (juryoku_lv) {
            case 0:
              entity.triggerEvent(`fuga`);
              if(entity.hasTag(`ryoiki_tenkai_set`) && entity.typeId === "minecraft:player"){
                runcmd(entity,`tag @e[family=fuga,tag=!fuga] add ryoiki_hit`);
                runcmd(entity,`scoreboard players remove @e[type=rai:fukuma_mizushi,name="${entity.name}",c=1] despawn 400`);
                runcmd(entity,`execute at @e[family=fukuma_mizushi,name="${PL}"] run tp @e[family=fuga,tag=!fuga] @e[r=64,${no_damage_selector}]`);
              }
              break;
            default:
              entity.triggerEvent(`fuga${juryoku_lv+1}`);
              if(entity.hasTag(`ryoiki_tenkai_set`) && entity.typeId === "minecraft:player"){
                runcmd(entity,`tag @e[family=fuga,tag=!fuga] add ryoiki_hit`);
                runcmd(entity,`scoreboard players remove @e[type=rai:fukuma_mizushi,name="${entity.name}",c=1] despawn 400`);
                runcmd(entity,`execute at @e[family=fukuma_mizushi,name="${PL}"] run tp @e[family=fuga,tag=!fuga] @e[r=64,${no_damage_selector}]`);
              }
              break;
          }
          runcmd(entity,`tag @e[family=fuga,tag=!fuga] add "PL_${PL}"`);
          runcmd(entity,`tag @e[family=fuga] add fuga`);
        break;
        case 'kai':
          var PL = entity.name;
          var juryoku_lv = getScore(entity,`juryoku_lv`);
          var no_damage_selector = `family=!damage,type=!falling_block,tag=!fukuma_mizushi_sukuna,tag=!no_player,tag=!ryoiki_tenkai_set,tag=!no_gameplayer,name=!"${entity.nameTag}"`;
          switch (juryoku_lv) {
            case 0:
              entity.triggerEvent(`kai`);
              if(entity.hasTag(`ryoiki_tenkai_set`) && entity.typeId === "minecraft:player"){
                runcmd(entity,`tag @e[family=kai,tag=!kai] add ryoiki_hit`);
                runcmd(entity,`scoreboard players remove @e[type=rai:fukuma_mizushi,name="${entity.name}",c=1] despawn 30`);
                runcmd(entity,`execute at @e[family=fukuma_mizushi,name="${PL}"] run tp @e[family=kai,tag=!kai] @e[r=64,${no_damage_selector}]`);
              }
              break;
            default:
              entity.triggerEvent(`kai${juryoku_lv+1}`);
              if(entity.hasTag(`ryoiki_tenkai_set`) && entity.typeId === "minecraft:player"){
                runcmd(entity,`tag @e[family=kai,tag=!kai] add ryoiki_hit`);
                runcmd(entity,`scoreboard players remove @e[type=rai:fukuma_mizushi,name="${entity.name}",c=1] despawn 30`);
                runcmd(entity,`execute at @e[family=fukuma_mizushi,name="${PL}"] run tp @e[family=kai,tag=!kai] @e[r=64,${no_damage_selector}]`);
              }
              break;
          }
          runcmd(entity,`tag @e[family=kai,tag=!kai] add "PL_${PL}"`);
          runcmd(entity,`tag @e[family=kai] add kai`);
        break;
        case 'koryu_jurei_attack':
          var {x, y, z} = entity.getViewDirection();
          entity.applyKnockback(x, z, 3, y*1.5);
          runcmd(entity,`tag @s add koryu_jurei_attack`);
          if(entity.hasTag(`geto_jurei_soujutsu`)){
            runcmd(entity,`execute as @s[scores={juryoku_lv=0}] anchored eyes positioned ^^^-1 run damage @e[family=!damage,tag=!koryu_jurei_attack,r=3] 3 entity_attack entity @s`);
            runcmd(entity,`execute as @s[scores={juryoku_lv=1..2}] anchored eyes positioned ^^^-1 run damage @e[family=!damage,tag=!koryu_jurei_attack,r=3] 4 entity_attack entity @s`);
            runcmd(entity,`execute as @s[scores={juryoku_lv=3..}] anchored eyes positioned ^^^-1 run damage @e[family=!damage,tag=!koryu_jurei_attack,r=3] 5 entity_attack entity @s`);
          }else {
            var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
            if(PL){
              runcmd(entity,`execute as @s[scores={juryoku_lv=0}] anchored eyes positioned ^^^-1 run damage @e[family=!damage,tag=!koryu_jurei_attack,name=!"${PL}",tag=!"PL_${PL}",r=3] 3 entity_attack entity @s`);
              runcmd(entity,`execute as @s[scores={juryoku_lv=1..2}] anchored eyes positioned ^^^-1 run damage @e[family=!damage,tag=!koryu_jurei_attack,name=!"${PL}",tag=!"PL_${PL}",r=3] 4 entity_attack entity @s`);
              runcmd(entity,`execute as @s[scores={juryoku_lv=3..}] anchored eyes positioned ^^^-1 run damage @e[family=!damage,tag=!koryu_jurei_attack,name=!"${PL}",tag=!"PL_${PL}",r=3] 5 entity_attack entity @s`);
            }else {
              runcmd(entity,`execute as @s[scores={juryoku_lv=0}] anchored eyes positioned ^^^-1 run damage @e[family=!damage,tag=!koryu_jurei_attack,r=3] 3 entity_attack entity @s`);
              runcmd(entity,`execute as @s[scores={juryoku_lv=1..2}] anchored eyes positioned ^^^-1 run damage @e[family=!damage,tag=!koryu_jurei_attack,r=3] 4 entity_attack entity @s`);
              runcmd(entity,`execute as @s[scores={juryoku_lv=3..}] anchored eyes positioned ^^^-1 run damage @e[family=!damage,tag=!koryu_jurei_attack,r=3] 5 entity_attack entity @s`);
            }
          }
          runcmd(entity,`tag @s remove koryu_jurei_attack`);
        break;
        case 'tokusa_setup':
          if(entity.hasTag(`summon_gyokuken`)){
            runcmd(entity,`execute unless entity @e[name="${entity.name}",family=gyokuken,tag=gyokuken] run function skill/tokusa/remove_juryoku/gyokuken`);
          }
          if(entity.hasTag(`summon_gyokuken2`)){
            runcmd(entity,`execute unless entity @e[name="${entity.name}",family=gyokuken,tag=gyokuken2] run function skill/tokusa/remove_juryoku/gyokuken2`);
          }
          if(entity.hasTag(`summon_gyokuken3`)){
            runcmd(entity,`execute unless entity @e[name="${entity.name}",family=gyokuken,tag=gyokuken3] run function skill/tokusa/remove_juryoku/gyokuken3`);
          }
          if(entity.hasTag(`summon_nue`)){
            runcmd(entity,`execute unless entity @e[name="${entity.name}",family=nue] run function skill/tokusa/remove_juryoku/nue`);
          }
          if(entity.hasTag(`summon_gama`)){
            runcmd(entity,`execute unless entity @e[name="${entity.name}",family=gama] run function skill/tokusa/remove_juryoku/gama`);
          }
          if(entity.hasTag(`summon_orochi`)){
            runcmd(entity,`execute unless entity @e[name="${entity.name}",family=orochi] run function skill/tokusa/remove_juryoku/orochi`);
          }
          if(entity.hasTag(`summon_bansyo`)){
            runcmd(entity,`execute unless entity @e[name="${entity.name}",family=bansyo] run function skill/tokusa/remove_juryoku/bansyo`);
          }
          if(entity.hasTag(`summon_makora`)){
            runcmd(entity,`execute unless entity @e[name="${entity.name}",family=makora] run function skill/tokusa/remove_juryoku/makora`);
          }
        break;
        default:
          if(id.match(/^tokusa_/)){
            let tokusa = id.replace(/^tokusa_/,'');
            if(entity.hasTag(`kango_aneitei_set`)){
              runcmd(entity,`execute unless entity @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=${tokusa},family=tokusa_shikigami,tag=!kango_aneitei] run tag @s add shikigami_summon_ok`);
              runcmd(entity,`execute as @s[tag=!shikigami_summon_ok] as @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=${tokusa},family=tokusa_shikigami,tag=!kango_aneitei] at @s run function entity/tokusa/shikigami_destroy`);
              runcmd(entity,`execute as @s[tag=!shikigami_summon_ok] run ride @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=${tokusa},family=tokusa_shikigami,family=orochi,tag=!kango_aneitei] evict_riders`);
              runcmd(entity,`execute as @s[tag=!shikigami_summon_ok] run tp @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=${tokusa},family=tokusa_shikigami,tag=!kango_aneitei] ~ 1000 ~`);
              runcmd(entity,`execute as @s[tag=!shikigami_summon_ok] run event entity @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=${tokusa},family=tokusa_shikigami,tag=!kango_aneitei] despawn`);
              runcmd(entity,`execute as @s[tag=shikigami_summon_ok] run function skill/tokusa/${tokusa}`);
              runcmd(entity,`tag @s remove shikigami_summon_ok`);
            }else {
              //式神を2種以上出している : no_shikigami_summon
              if(tokusa === "nue" || tokusa === "gama"){
                runcmd(entity,`execute if entity @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=!tyobuku,type=!player,family=seiteishirazu] run tag @s add summon_seiteishirazu`);
                runcmd(entity,`playsound note.bass @s[tag=summon_seiteishirazu] ~~1~`);
                runcmd(entity,`tellraw @s[tag=summon_seiteishirazu] {"rawtext":[{"translate":"text.tokusa.summon_seiteishirazu_no_summon"}]}`);
              }else if(tokusa === "seiteishirazu"){
                runcmd(entity,`execute if entity @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=!tyobuku,type=!player,family=nue_gama] run tag @s add no_summon_seiteishirazu`);
                runcmd(entity,`playsound note.bass @s[tag=no_summon_seiteishirazu] ~~1~`);
                runcmd(entity,`tellraw @s[tag=no_summon_seiteishirazu] {"rawtext":[{"translate":"text.tokusa.no_summon_seiteishirazu"}]}`);
              }
              runcmd(entity,`execute if entity @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=!tyobuku,family=seiteishirazu] if entity @r[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=!tyobuku,type=!player,family=!seiteishirazu] run tag @s add no_shikigami_summon`);
              runcmd(entity,`execute if entity @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=!tyobuku,family=datto] if entity @r[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=!tyobuku,type=!player,family=!datto] run tag @s add no_shikigami_summon`);
              runcmd(entity,`execute unless entity @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=!tyobuku,family=multiple_shikigami] run tag @r[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=!tyobuku,type=!player] add no_shikigami_test`);
              runcmd(entity,`execute unless entity @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=!tyobuku,family=multiple_shikigami] run tag @r[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=!tyobuku,type=!player,tag=!no_shikigami_test] add no_shikigami_test2`);
              runcmd(entity,`execute unless entity @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=!tyobuku,family=multiple_shikigami] if entity @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=!tyobuku,tag=no_shikigami_test] if entity @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=!tyobuku,tag=no_shikigami_test2] run tag @s add no_shikigami_summon`);
              runcmd(entity,`tag @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=!tyobuku,type=!player,tag=no_shikigami_test] remove no_shikigami_test`);
              runcmd(entity,`tag @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=!tyobuku,type=!player,tag=no_shikigami_test2] remove no_shikigami_test2`);
              //出そうとしている式神がワールドに存在しない : shikigami_summon_ok
              runcmd(entity,`execute unless entity @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=${tokusa},family=tokusa_shikigami] run tag @s add shikigami_summon_ok`);
              runcmd(entity,`execute as @s[tag=!shikigami_summon_ok] as @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=${tokusa},family=tokusa_shikigami,tag=!ride] at @s run function entity/tokusa/shikigami_destroy`);
              runcmd(entity,`execute as @s[tag=!shikigami_summon_ok] if entity @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=${tokusa},family=tokusa_shikigami,tag=ride] run tp ~~~`);
              runcmd(entity,`execute as @s[tag=!shikigami_summon_ok] run ride @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=${tokusa},family=tokusa_shikigami,family=orochi] evict_riders`);
              runcmd(entity,`execute as @s[tag=!shikigami_summon_ok] run tp @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=${tokusa},family=tokusa_shikigami] ~ 1000 ~`);
              runcmd(entity,`execute as @s[tag=!shikigami_summon_ok] run event entity @e[tag=tokusa_shikigami,tag="PL_${entity.name}",tag=${tokusa},family=tokusa_shikigami] despawn`);
              //式神を新しく召喚出来るが式神を2種以上既に出している場合の処理
              runcmd(entity,`playsound note.bass @s[tag=no_shikigami_summon,tag=shikigami_summon_ok,tag=!summon_seiteishirazu,tag=!no_summon_seiteishirazu] ~~1~`);
              runcmd(entity,`tellraw @s[tag=no_shikigami_summon,tag=shikigami_summon_ok,tag=!summon_seiteishirazu,tag=!no_summon_seiteishirazu] {"rawtext":[{"translate":"text.tokusa.no_shikigami_summon"}]}`);
              //式神を2種未満で式神を新しく召喚できる場合の処理
              runcmd(entity,`execute as @s[tag=!no_shikigami_summon,tag=shikigami_summon_ok,tag=!summon_seiteishirazu,tag=!no_summon_seiteishirazu] run function skill/tokusa/${tokusa}`);
              runcmd(entity,`tag @s remove shikigami_summon_ok`);
              runcmd(entity,`tag @s remove no_shikigami_summon`);
              runcmd(entity,`tag @s remove summon_seiteishirazu`);
              runcmd(entity,`tag @s remove no_summon_seiteishirazu`);
            }
          }
        break;
      }
    }
});
function rand() {
    return Math.random() * 2.0 - 1.0;
};
function random_integer(min, max){
  return Math.floor( Math.random() * (max + 1 - min) ) + min ;
}

const objDB = {};
function getScore(target, objective) {
  try {
    return (objDB[objective] ??= world.scoreboard.getObjective(objective))?.getScore(target) ?? 0;
  } catch (e) {
    return 0;
  }
};
world.beforeEvents.explosion.subscribe(eventData => {
  const entity = eventData.source;
  const dimension = world.getDimension(entity.dimension.id);
  //explode despawn
  if(entity?.hasTag(`block_explode`))return;
  let pos = entity.location;
  runcmd(dimension,`particle j:vanilla_explode ${pos.x} ${pos.y} ${pos.z}`);
});
world.afterEvents.itemUse.subscribe(eventData => {
  const player = eventData.source;
  const item = eventData.itemStack;
  if(item?.typeId === "minecraft:skull") {
    ui(player);
  }
});
world.afterEvents.entitySpawn.subscribe(eventData => {
  const entity = eventData.entity;
  runcmd(entity,`tag @s[family=damage_sneaking] add damage_sneaking_entity`);
  runcmd(entity,`tag @s[family=jurei] add jurei`);
  runcmd(entity,`tag @s[family=kill_human_mob] add kill_human_mob`);
});

world.afterEvents.entityHurt.subscribe(eventData => {
  const player = eventData.hurtEntity;
  const damageSource = eventData.damageSource;
  const damager = damageSource?.damagingEntity;
  let projectile_damager = damageSource?.damagingProjectile;
  projectile_damager = projectile_damager ? projectile_damager : damager;

  //--damager--//

  try {
    //nue
    if(damager?.typeId === "rai:nue") {
      runcmd(damager,`execute anchored eyes run summon rai:block_explode ^^^0.5 ~ ~ explode3`);
      runcmd(damager,`function skill/tokusa_shikigami/punch`);
      runcmd(damager,`playsound j.kaminari @a ~~~`);
      runcmd(player,`effect @s slowness 1 3 true`);
      runcmd(player,`camerashake add @s[type=player] 1.5 0.5 rotational`);
      if(!damager.hasTag(`kango_aneitei`)){
        player.applyKnockback(player.location.x-damager.location.x, player.location.z-damager.location.z, 1, 1);
      }
    }else if(damager?.typeId === "minecraft:player") {
      const { container } = damager.getComponent('minecraft:inventory');
      const slot = container.getSlot(damager.selectedSlot);
      const damager_item = slot?.typeId;
      const item_num = getScore(damager,`item_num`);
      if(damager.hasTag(`surei`) && damageSource.cause === "entityAttack" && item_num === 2 && damager_item === "rai:surei") {
        runcmd(damager,`function skill/surei/tomonari`);
        runcmd(player,`tag @e[tag="tomonari_${damager.name}"] remove "tomonari_${damager.name}"`);
        runcmd(player,`tag @s add "tomonari_${damager.name}"`);
        if(player.typeId === "minecraft:player"){
          runcmd(damager,`tellraw @s {"rawtext":[{"translate":"text.surei.tomonari"},{"text":"${player.name}"}]}`);
        }else {
          runcmd(damager,`tellraw @s {"rawtext":[{"translate":"text.surei.tomonari"},{"translate":"entity.${player.typeId.replace(/^minecraft:/,'')}.name"}]}`);
        }
      }else if(damageSource.cause === "entityAttack" && damager_item === "rai_weapon:yuun") {
        runcmd(player,`particle minecraft:large_explosion ~~1~`);
        if(eventData.damage/10 <= 1){
          runcmd(player,`playsound random.explode @a ~~1~ ${eventData.damage/10} 0.9`);
        }else {
          runcmd(player,`playsound random.explode @a ~~1~ 1 0.9`);
          runcmd(player,`playsound random.explode @a ~~1~ ${eventData.damage/10} 0.9`);
        }
        var {x, y, z} = damager.getViewDirection();
        y = y > 5 ? 5 : y;
        y = y > -0.25 ? y+0.7 : y-1;
        player.applyKnockback(x, z, eventData.damage/1.5+1, y*eventData.damage/10);
        damager.triggerEvent(`mark_variant35`);
      }else if(!player.hasTag(`jurei_despawn`) && player.hasTag(`jurei_torikomi`) && damageSource.cause === "entityAttack" && damager_item === "rai:jurei_soujutsu") {
        runcmd(damager,`scoreboard players remove @s[scores={juryoku=100..}] juryoku 100`);
        runcmd(damager,`give @s ${player.typeId}_ball 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}`);
        player.addTag(`jurei_despawn`);
        player.triggerEvent(`despawn`);
      }
    }
    //entity weapon
    if(damageSource.cause === "entityAttack" && damager.hasTag(`yuun`) && !damager.hasTag(`cooltime`)) {
      runcmd(player,`particle minecraft:large_explosion ~~1~`);
      if(eventData.damage/10 <= 1){
        runcmd(player,`playsound random.explode @a ~~1~ ${eventData.damage/10} 0.9`);
      }else {
        runcmd(player,`playsound random.explode @a ~~1~ 1 0.9`);
        runcmd(player,`playsound random.explode @a ~~1~ ${eventData.damage/10} 0.9`);
      }
      var {x, y, z} = damager.getViewDirection();
      y = y > 5 ? 5 : y;
      y = y > -0.25 ? y+0.7 : y-1;
      player.applyKnockback(x, z, eventData.damage/1.5+1, y*eventData.damage/10);
      damager.triggerEvent(`mark_variant35`);
    }else if(damageSource.cause === "entityAttack" && damager.typeId === "rai:koryu_jurei" && damager.hasTag(`koryu_jurei_attack`)) {
      player.applyKnockback(player.location.x-damager.location.x, player.location.z-damager.location.z, 1, 1.75);
    }
  
    //--player--//
  
    //makora & damage sneaking
    if(!player || eventData.damage < 0)return;
    else if(player.typeId === "rai:makora" && getScore(player,`cooltime2`) < 100) {
      if(Math.random() > 0.05 && eventData.damage < 30){
        runcmd(player,`effect @s regeneration ${eventData.damage/30 < 1 ? 1 : Math.floor(eventData.damage/30)} 4 true`);
      }else {
        runcmd(player,`effect @s regeneration ${eventData.damage/10 < 1 ? 1 : Math.floor(eventData.damage/10)} 5 true`);
      }
      if(!player.hasTag('makora_id_'+projectile_damager?.typeId) || projectile_damager?.typeId === "minecraft:player"){
        if(player.hasTag('makora_id_minecraft:player') && projectile_damager?.typeId === "minecraft:player"){
          const { container } = damager.getComponent('minecraft:inventory');
          const slot = container.getSlot(damager.selectedSlot);
          const damager_item = slot?.typeId;
          if(damager_item && damager_item.match(/^rai_weapon:/) && !player.hasTag('makora_id_'+damager_item)){
            runcmd(player,`function entity/tokusa/makora_gagon`);
            runcmd(player,`tag @s add makora_id_${damager_item}`);
            runcmd(player,`effect @s regeneration 0`);
          }
        }else {
          runcmd(player,`function entity/tokusa/makora_gagon`);
          runcmd(player,`tag @s add makora_id_${projectile_damager?.typeId}`);
          runcmd(player,`effect @s regeneration 0`);
        }
      }
    }else if(player.hasTag(`damage_sneaking_entity`) && Math.random() < 0.3) {
      runcmd(player,`tag @s add damage_sneaking`);
    }
    if(player.typeId === "minecraft:player"){
      if(getScore(player,`cooltime2`) < 3){
        runcmd(player,`scoreboard players set @s cooltime2 2`);
        runcmd(player,`tag @s add cooltime2`);
      }
      //反転術式
      if(damageSource.cause !== "fall" && damageSource.cause !== "void" && eventData.damage >= 3 && !player.hasTag(`hanten_jutsushiki`) && !player.hasTag(`maki`) && !player.hasTag(`juryoku0`)){
        let damage = eventData.damage;
        damage = damage >= 40 ? 0 : damage;
        const random = Math.random()*40;
        if(random <= damage/30){
          runcmd(player,`function tag/juryoku_sousa/died_hanten_jutsushiki`);
        }
      }
      //領域展開実績
      if(damageSource.cause !== "fall" && damageSource.cause !== "void" && eventData.damage >= 3 && player.hasTag(`tokusa`) && !player.hasTag(`kango_aneitei`) && player.hasTag(`tyobuku_nue`) && player.hasTag(`tyobuku_gama`) && player.hasTag(`tyobuku_orochi`) && player.hasTag(`tyobuku_bansyo`) && (!player.hasTag(`gyokuken`) || !player.hasTag(`gyokuken2`))){
        let damage = eventData.damage;
        damage = damage >= 40 ? 0 : damage;
        const random = Math.random()*40;
        if(random <= damage/6){
          runcmd(player,`function tag/tokusa/kango_aneitei`);
        }
      }
      //掌印のキャンセル等
      if(damageSource.cause === "suicide" || damageSource.cause === "projectile" || damageSource.cause === "entityAttack" || damageSource.cause === "entityExplosion" || damageSource.cause === "lightning"){
        if(player.hasTag(`tokusa_shikigami_cooltime`)) {
          runcmd(player,`function tick2/cooltime2/tokusa/reset_tokusa_shikigami_cooltime`);
          runcmd(player,`playsound note.bass @s ~~1~`);
          runcmd(player,`tellraw @s {"rawtext":[{"translate":"text.tokusa.cooltime_hurt"}]}`);
        }else if(player.hasTag(`byakuren`)) {
          runcmd(player,`function tick2/cooltime2/sekketsu/byakuren2`);
          runcmd(player,`playsound note.bass @s ~~1~`);
          runcmd(player,`tellraw @s {"rawtext":[{"translate":"text.sekketsu.cooltime_hurt"}]}`);
        }else if(player.hasTag(`attack_tomonari`)) {
          runcmd(player,`tag @s remove attack_tomonari`);
          runcmd(player,`playsound note.bass @s ~~1~`);
          runcmd(player,`tellraw @s {"rawtext":[{"translate":"text.surei.cooltime_hurt"}]}`);
          tag.forEach(tag=>{
            if(tag.startsWith("tomonari_")){
              entity.removeTag(tag);
            }
          });
        }
      }
      if(player.getComponent('minecraft:health').currentValue <= 10){
        runcmd(player,`event entity @e[tag=ryoiki_draw,name="${player.name}",family=ryoiki_tenkai] despawn`);
      }
    }
    //黒閃
    if(player.hasTag(`black_flash_damage`)){
      player.removeTag(`black_flash_damage`);
      var {x, z} = damager.getViewDirection();
      player.applyKnockback(x, z, eventData.damage/5+1, 0.5);
      runcmd(player,`particle j:black_flash_hit ~~1~`);
      if(player.typeId === "minecraft:player"){
        runcmd(player,`camerashake add @s 2.5 0.5 rotational`);
      }
      if(damager.typeId === "minecraft:player"){
        runcmd(damager,`function tag/skill/black_flash`);
      }
    }
    if(player.hasTag(`kick_damage`)){
      player.removeTag(`kick_damage`);
      var {x, z} = damager.getViewDirection();
      player.applyKnockback(x, z, eventData.damage/3.5+1, 0.3);
    }else if(player.hasTag(`manji_kick_damage`)){
      player.removeTag(`manji_kick_damage`);
      var {x, z} = damager.getViewDirection();
      player.applyKnockback(x, z, eventData.damage/2+1, -0.25);
    }
  } catch (e) {
  }
});
world.afterEvents.entityDie.subscribe(eventData => {
  const player = eventData.deadEntity;
  const damageSource = eventData.damageSource;
  const damager = damageSource?.damagingEntity;
  try {
    if(player.typeId === "minecraft:player"){
      runcmd(player,`scriptevent j:died`);
      runcmd(player,`function system/died`);
      player.triggerEvent(`died`);
    }else if(!player.hasTag(`died`)){
      player.addTag(`cooltime`);
      player.addTag(`cooltime2`);
      runcmd(player,`replaceitem entity @s slot.weapon.mainhand 0 air`);
      if(player.typeId.match(/_jurei$/)){
        runcmd(player,`execute anchored eyes run particle j:jurei_death ~~~`);
      }
      if(damager){
        if(damager.typeId === "minecraft:player"){
          runcmd(damager,`tag @s add killer_player`);
        }else {
          const PL = damager.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
          if(PL){
            runcmd(player,`tag "${PL}" add killer_player`);
          }else if(damager.nameTag){
            runcmd(player,`tag "${damager.nameTag}" add killer_player`);
          }
        }
        if(player.hasTag(`jurei`)){
          runcmd(player,`tag @a[r=10] add killer_player`);
          runcmd(player,`execute if entity @s[family=4kyu_jurei] as @a[tag=killer_player] run function mission/kill/4kyu_jurei`);
          runcmd(player,`execute if entity @s[family=3kyu_jurei] as @a[tag=killer_player] run function mission/kill/3kyu_jurei`);
          runcmd(player,`execute if entity @s[family=2kyu_jurei] as @a[tag=killer_player] run function mission/kill/2kyu_jurei`);
          runcmd(player,`execute if entity @s[family=1kyu_jurei] as @a[tag=killer_player] run function mission/kill/1kyu_jurei`);
          runcmd(player,`execute if entity @s[family=tokyu_jurei] as @a[tag=killer_player] run function mission/kill/tokyu_jurei`);
        }else if(player.typeId === "rai:maki"){
          runcmd(player,`execute as @a[tag=killer_player,tag=!sekkin_skill] run function tag/skill/sekkin`);
        }else if(player.typeId === "rai:inumaki"){
          runcmd(player,`execute as @a[tag=killer_player,tag=!bakuten_skill] run function tag/skill/bakuten`);
        }else if(player.typeId === "rai:panda"){
          runcmd(player,`execute as @a[tag=killer_player,tag=!strong_punch_skill] run function tag/skill/strong_punch`);
        }else if(player.typeId === "rai:itadori"){
          runcmd(player,`execute as @a[tag=killer_player,tag=itadori,tag=!manji_kick_itadori] run function tag/itadori/manji_kick`);
        }else if(player.typeId === "rai:toudo"){
          runcmd(player,`execute as @a[tag=killer_player,tag=!challenge_black_flash] run function tag/challenge/black_flash`);
        }else if(player.typeId.match(/^minecraft:villager/)){
          runcmd(player,`execute as @a[tag=killer_player] run function command/kill_human_mob`);
        }
        runcmd(player,`tag @a remove killer_player`);
      }
      player.addTag(`died`);
    }
  } catch (e) {
  }
});
world.afterEvents.projectileHit.subscribe(eventData => {
  const entityHit = eventData.getEntityHit()?.entity;
  const projectile = eventData.projectile;
  const shooter = eventData.source;
  try {
    if(projectile?.hasTag(`player_name_entity`) && shooter.typeId === "minecraft:player"){
      projectile.nameTag = 'PL_'+shooter.name;
      if(projectile.hasTag(`tokusa_shikigami`) && !shooter.hasTag(`tokusa`)){
        projectile.triggerEvent(`despawn`);
      }else if(projectile.hasTag(`jurei_soujutsu_jurei`)){
        const juryoku_lv = getScore(projectile,`juryoku_lv`);
        projectile.nameTag = projectile.nameTag+juryoku_lv;
        let randomPos = 0;
        while (1.5 > randomPos && randomPos > -1.5) {
          randomPos = (Math.random()-Math.random())*4;
        }
        runcmd(projectile,`execute at "${shooter.name}" rotated ~ 0 run tp ^${randomPos}^^`);
        runcmd(projectile,`execute at "${shooter.name}" rotated ~ 0 run summon rai:particle ^${randomPos}^^ ~ 0 jurei_summon`);
      }else if(projectile.hasTag(`jurei_soujutsu_jurei2`)){
        const juryoku_lv = getScore(projectile,`juryoku_lv`);
        projectile.nameTag = projectile.nameTag+juryoku_lv;
      }
    }else if(projectile?.hasTag(`player_name_entity2`) && shooter.typeId === "minecraft:player"){
      projectile.nameTag = shooter.name;
      const juryoku_lv = getScore(shooter,`juryoku_lv`);
      runcmd(projectile,`scoreboard players set @s juryoku_lv ${juryoku_lv ? juryoku_lv : 0}`);
    }else if(projectile?.typeId === "rai:nail"){
      if(shooter.typeId === "minecraft:player"){
        projectile.addTag(`PL_`+shooter.name);
        if(entityHit){
          entityHit.addTag(`kanzashi_`+shooter.name);
        }
      }else {
        projectile.addTag(`nail`);
      }
    }
  } catch (e) {
  }
});
async function ryoiki_tenkai_despawn(entity){
  if(entity.typeId === "rai:fukuma_mizushi" && entity.nameTag !== ""){
    runcmd(entity,`execute as @a[name="${entity.nameTag}"] run function skill/sukuna/ryoiki_tenkai2`);
    return;
  }else if(entity.typeId === "rai:kango_aneitei" && entity.nameTag !== ""){
    if(entity.hasTag(`ryoiki_draw`)){
      runcmd(entity,`tag @s remove ryoiki_draw`);
      runcmd(entity,`event entity @e[name=!"${entity.nameTag}",family=ryoiki_tenkai,r=41,tag=ryoiki_draw] ryoiki_draw`);
    }
    //式神デスポーン
    runcmd(entity,`event entity @e[tag="PL_${entity.nameTag}",tag=kango_aneitei] despawn`);
    runcmd(entity,`execute as @a[name="${entity.nameTag}"] run function skill/tokusa/ryoiki_tenkai2`);
    return;
  }else if(entity.typeId === "rai:muryo_kusho" && entity.nameTag !== ""){
    if(entity.hasTag(`ryoiki_draw`)){
      runcmd(entity,`tag @s remove ryoiki_draw`);
      runcmd(entity,`event entity @e[name=!"${entity.nameTag}",family=ryoiki_tenkai,r=41,tag=ryoiki_draw] ryoiki_draw`);
    }
    runcmd(entity,`execute as @a[name="${entity.nameTag}"] run function skill/mukagen/ryoiki_tenkai2`);
    return;
  }
}
world.afterEvents.dataDrivenEntityTriggerEvent.subscribe(eventData => {
  const entity = eventData.entity;
  const id = eventData.id;
  try {
    if(entity?.typeId === "minecraft:player")return;
    else if(id.match(/^PlayerName_/)){
      if(id.match(/^PlayerName_jurei_soujutsu/)){
        if(entity.nameTag !== ""){
          runcmd(entity,`scoreboard players set @s juryoku_lv ${entity.nameTag[entity.nameTag.length-1]}`);
          entity.nameTag = entity.nameTag.slice(0, -1);
          let PL = entity.nameTag.replace(/^PL_/,'');
          runcmd(entity,`execute if entity @a[name="${PL}",tag=!jusoshi,tag=!jurei] run tag @s add school_team`);
          if(id === "PlayerName_jurei_soujutsu_worm_jurei_up" || id === "PlayerName_jurei_soujutsu_daruma_jurei"){
            runcmd(entity,`execute rotated as @a[name="${PL}"] run tp ~~~ ~ 0`);
          }
        }else {
          if(id === "PlayerName_jurei_soujutsu_worm_jurei_up" || id === "PlayerName_jurei_soujutsu_daruma_jurei"){
            runcmd(entity,`tag @s add school_team`);
            runcmd(entity,`tag @s add geto_jurei_soujutsu`);
          }
        }
      }
      if(entity.nameTag !== ""){
        entity.addTag(entity.nameTag);
        entity.addTag(`PlayerName_entity`);
        let PL = entity.nameTag.replace(/^PL_/,'');
        entity.nameTag = "";
        if(id.match(/^PlayerName_tokusa_/)){
          runcmd(entity,`execute if entity @a[name="${PL}",tag=tokusa] run tag @s add tokusa_shikigami`);
          runcmd(entity,`execute if entity @a[name="${PL}",tag=!jusoshi,tag=!jurei] run tag @s add school_team`);
          if(entity.typeId === "rai:makora"){
            runcmd(entity,`scoreboard players set @s juryoku_lv 2`);
          }else {
            runcmd(entity,`execute if entity @a[name="${PL}",scores={juryoku_lv=1}] run scoreboard players set @s juryoku_lv 1`);
            runcmd(entity,`execute if entity @a[name="${PL}",scores={juryoku_lv=2}] run scoreboard players set @s juryoku_lv 2`);
            runcmd(entity,`execute if entity @a[name="${PL}",scores={juryoku_lv=3..}] run scoreboard players set @s juryoku_lv 3`);
          }
          if(id === "PlayerName_tokusa_ride"){
            if(entity.typeId === "rai:nue"){
              runcmd(entity,`execute unless entity @a[name="${PL}",tag=kango_aneitei_set] unless entity @a[name="${PL}",tag=tokusa,scores={juryoku=200..}] run event entity @s despawn`);
              runcmd(entity,`scoreboard players remove @a[name="${PL}",tag=tokusa,tag=!kango_aneitei_set] juryoku 200`);
              runcmd(entity,`tp "${PL}"`);
              runcmd(entity,`ride "${PL}" start_riding @s`);
              runcmd(entity,`tag @s add ride_set`);
            }else if(entity.typeId === "rai:bansyo"){
              runcmd(entity,`execute unless entity @a[name="${PL}",tag=tokusa,tag=!kango_aneitei_set,scores={juryoku=350..}] run event entity @s despawn`);
              runcmd(entity,`scoreboard players remove @a[name="${PL}",tag=tokusa,tag=!kango_aneitei_set] juryoku 350`);
              runcmd(entity,`tp "${PL}"`);
              runcmd(entity,`ride "${PL}" start_riding @s`);
              runcmd(entity,`tag @s add ride_set`);
              runcmd(entity,`event entity @s bansyo_fall_tp`);
            }
          }else if(id === "PlayerName_tokusa_start"){
            runcmd(entity,`execute if entity @a[name="${PL}",tag=tokusa,tag=kango_aneitei_set] run function entity/tokusa/kango_aneitei_shikigami_set`);
            if(entity.typeId === "rai:nue"){
              runcmd(entity,`execute unless entity @a[name="${PL}",tag=kango_aneitei_set] unless entity @a[name="${PL}",tag=tokusa,scores={juryoku=200..}] run event entity @s despawn`);
              runcmd(entity,`execute as @a[name="${PL}",tag=tokusa,tag=!kango_aneitei_set,scores={juryoku=200..}] run function skill/tokusa/juryoku_set/nue`);
            }else if(entity.typeId === "rai:gama"){
              runcmd(entity,`execute unless entity @a[name="${PL}",tag=kango_aneitei_set] unless entity @a[name="${PL}",tag=tokusa,scores={juryoku=100..}] run event entity @s despawn`);
              runcmd(entity,`execute as @a[name="${PL}",tag=tokusa,tag=!kango_aneitei_set,scores={juryoku=100..}] run function skill/tokusa/juryoku_set/gama`);
            }else if(entity.typeId === "rai:orochi"){
              runcmd(entity,`execute unless entity @a[name="${PL}",tag=kango_aneitei_set] unless entity @a[name="${PL}",tag=tokusa,scores={juryoku=100..}] run event entity @s despawn`);
              runcmd(entity,`execute as @a[name="${PL}",tag=tokusa,tag=!kango_aneitei_set,scores={juryoku=100..}] run function skill/tokusa/juryoku_set/orochi`);
              runcmd(entity,`execute if entity @a[name="${PL}",tag=tokusa,tag=kango_aneitei_set] run scoreboard players remove @e[name="${PL}",type=rai:kango_aneitei,c=1] despawn 50`);
            }else if(entity.typeId === "rai:bansyo"){
              runcmd(entity,`execute unless entity @a[name="${PL}",tag=kango_aneitei_set] unless entity @a[name="${PL}",tag=tokusa,scores={juryoku=350..}] run event entity @s despawn`);
              runcmd(entity,`execute as @a[name="${PL}",tag=tokusa,tag=!kango_aneitei_set,scores={juryoku=350..}] run function skill/tokusa/juryoku_set/bansyo`);
              runcmd(entity,`execute if entity @a[name="${PL}",tag=tokusa,tag=kango_aneitei_set] run scoreboard players remove @e[name="${PL}",type=rai:kango_aneitei,c=1] despawn 400`);
              runcmd(entity,`execute as @s[tag=!kango_aneitei] run scriptevent j:shikigami_player_look`);
              runcmd(entity,`execute as @s[tag=!kango_aneitei] run function skill/tokusa_shikigami/bansyo_mizu`);
            }else if(entity.typeId === "rai:makora"){
              runcmd(entity,`execute unless entity @a[name="${PL}",tag=kango_aneitei_set] unless entity @a[name="${PL}",tag=tokusa,scores={juryoku=600..}] run event entity @s despawn`);
              runcmd(entity,`execute as @a[name="${PL}",tag=tokusa,tag=!kango_aneitei_set,scores={juryoku=600..}] run function skill/tokusa/juryoku_set/makora`);
              runcmd(entity,`execute if entity @a[name="${PL}",tag=tokusa,tag=kango_aneitei_set] run scoreboard players remove @e[name="${PL}",type=rai:kango_aneitei,c=1] despawn 600`);
            }
          }else if(id === "PlayerName_tokusa_kango_aneitei"){
            runcmd(entity,`execute unless entity @a[name="${PL}",tag=tokusa,tag=kango_aneitei_set] run event entity @s despawn`);
            runcmd(entity,`execute if entity @a[name="${PL}",tag=tokusa,tag=kango_aneitei_set] run function entity/tokusa/kango_aneitei_shikigami_set`);
            if(entity.typeId === "rai:nue"){
              runcmd(entity,`execute if entity @a[name="${PL}",tag=tokusa,tag=kango_aneitei_set] run scoreboard players remove @e[name="${PL}",type=rai:kango_aneitei,c=1] despawn 100`);
            }else if(entity.typeId === "rai:gama"){
              runcmd(entity,`execute if entity @a[name="${PL}",tag=tokusa,tag=kango_aneitei_set] run scoreboard players remove @e[name="${PL}",type=rai:kango_aneitei,c=1] despawn 75`);
              runcmd(entity,`event entity @s gama_bero`);
            }
          }else if(id.match(/^PlayerName_tokusa_gyokuken/)){
            runcmd(entity,`execute if entity @a[name="${PL}",tag=tokusa,tag=kango_aneitei_set] run tag @s add kango_aneitei`);
            if(id === "PlayerName_tokusa_gyokuken"){
              runcmd(entity,`execute unless entity @a[name="${PL}",tag=kango_aneitei_set] unless entity @a[name="${PL}",tag=tokusa,scores={juryoku=150..}] run event entity @s despawn`);
              runcmd(entity,`execute if entity @a[name="${PL}",tag=tokusa,tag=kango_aneitei_set] run event entity @s kango_aneitei`);
              runcmd(entity,`execute as @a[name="${PL}",tag=tokusa,tag=!kango_aneitei_set,scores={juryoku=150..}] run function skill/tokusa/juryoku_set/gyokuken`);
              runcmd(entity,`execute if entity @a[name="${PL}",tag=tokusa,tag=kango_aneitei_set] run scoreboard players remove @e[name="${PL}",type=rai:kango_aneitei,c=1] despawn 300`);
            }else if(id === "PlayerName_tokusa_gyokuken2"){
              runcmd(entity,`execute unless entity @a[name="${PL}",tag=kango_aneitei_set] unless entity @a[name="${PL}",tag=tokusa,scores={juryoku=150..}] run event entity @s despawn`);
              runcmd(entity,`execute if entity @a[name="${PL}",tag=tokusa,tag=kango_aneitei_set] run event entity @s kango_aneitei`);
              runcmd(entity,`execute as @a[name="${PL}",tag=tokusa,tag=!kango_aneitei_set,scores={juryoku=150..}] run function skill/tokusa/juryoku_set/gyokuken2`);
              runcmd(entity,`execute if entity @a[name="${PL}",tag=tokusa,tag=kango_aneitei_set] run scoreboard players remove @e[name="${PL}",type=rai:kango_aneitei,c=1] despawn 300`);
            }else if(id === "PlayerName_tokusa_gyokuken3"){
              runcmd(entity,`execute unless entity @a[name="${PL}",tag=kango_aneitei_set] unless entity @a[name="${PL}",tag=tokusa,scores={juryoku=200..}] run event entity @s despawn`);
              runcmd(entity,`execute if entity @a[name="${PL}",tag=tokusa,tag=kango_aneitei_set] run event entity @s kango_aneitei2`);
              runcmd(entity,`execute as @a[name="${PL}",tag=tokusa,tag=!kango_aneitei_set,scores={juryoku=200..}] run function skill/tokusa/juryoku_set/gyokuken3`);
              runcmd(entity,`execute if entity @a[name="${PL}",tag=tokusa,tag=kango_aneitei_set] run scoreboard players remove @e[name="${PL}",type=rai:kango_aneitei,c=1] despawn 400`);
            }
          }
        }
      }
    }else {
      switch (id) {
        case 'attack':
          if(getScore(entity,`no_move`) == 0) {
            runcmd(entity,`execute unless entity @s[scores={no_move=0..}] run ride @s stop_riding`);
          }
        break;
        case 'start2':
          runcmd(entity,`scoreboard players set @s despawn 900`);
          runcmd(entity,`scoreboard players operation @s despawn = @a[name="${entity.nameTag}"] max_juryoku`);
          runcmd(entity,`tag @a[name="${entity.nameTag}"] add ryoiki_tenkai_set`);
          runcmd(entity,`event entity @a[name="${entity.nameTag}"] knockback_resistance`);
        break;
        case 'ryoiki_draw':
          var juryoku_lv = getScore(entity,`juryoku_lv`);
          runcmd(entity,`execute unless entity @e[name=!"${entity.nameTag}",r=41,tag=ryoiki_start,scores={juryoku_lv=${juryoku_lv}},family=ryoiki_tenkai,family=!ryoiki_tenkai2] run event entity @s start2`);
          runcmd(entity,`execute unless entity @e[name=!"${entity.nameTag}",r=41,tag=ryoiki_start,scores={juryoku_lv=${juryoku_lv}},family=ryoiki_tenkai,family=!ryoiki_tenkai2] run tag @s remove ryoiki_draw`);
          runcmd(entity,`execute unless entity @e[name=!"${entity.nameTag}",r=41,tag=ryoiki_start,scores={juryoku_lv=${juryoku_lv}},family=ryoiki_tenkai,family=!ryoiki_tenkai2] as "${entity.nameTag}" run function entity/ryoiki_tenkai/ryoiki_draw_end`);
          runcmd(entity,`execute if entity @e[name=!"${entity.nameTag}",r=41,tag=ryoiki_start,scores={juryoku_lv=${juryoku_lv}},family=ryoiki_tenkai,family=!ryoiki_tenkai2] as "${entity.nameTag}" run function entity/ryoiki_tenkai/ryoiki_draw_start`);
        break;
        case 'fukuma_mizushi_attack':
          var no_damage_selector = `family=!damage,type=!falling_block,tag=!fukuma_mizushi_sukuna,tag=!no_player,tag=!no_gameplayer`;
          if(entity.nameTag !== "")no_damage_selector = no_damage_selector+`,name=!"${entity.nameTag}"`
          runcmd(entity,`execute as @e[r=64,${no_damage_selector}] at @s run playsound j.slash @a ~~~ 0.5 1.3`);
          runcmd(entity,`execute as @e[r=64,${no_damage_selector},tag=!juryoku0] at @s run particle j:hati ~~1~`);
          if(entity.nameTag !== ""){
            runcmd(entity,`damage @e[tag=!pvp,r=64,${no_damage_selector}] 1 suicide`);
            runcmd(entity,`damage @e[tag=!pvp,r=64,type=!player,family=!makora,${no_damage_selector}] 5 suicide`);
            runcmd(entity,`damage @e[tag=!pvp,r=64,type=item] 10 entity_explosion`);
          }else {
            runcmd(entity,`damage @e[r=64,${no_damage_selector}] 1 suicide`);
            runcmd(entity,`damage @e[r=64,type=!player,family=!makora,${no_damage_selector}] 5 suicide`);
            runcmd(entity,`damage @e[r=64,type=item] 10 entity_explosion`);
          }
          runcmd(entity,`summon rai:fukuma_explode ~~~ 0 0 fukuma_explode_start`);
          runcmd(entity,`summon rai:fukuma_explode ~~~ 0 0 fukuma_explode_start`);
          runcmd(entity,`summon rai:fukuma_explode ~~~ 0 0 fukuma_explode_start2`);
          runcmd(entity,`summon rai:fukuma_explode ~~~ 0 0 fukuma_explode_start2`);
        break;
        case 'fukuma_explode_start':
          var x = rand(),
              z = rand();
          if(x * x + z * z < 1) {
            x = x*50;
            z = z*50;
            runcmd(entity,`particle j:fukuma_kai ~${x} ~ ~${z}`);
            runcmd(entity,`playsound j.slash @a ~${x} ~ ~${z} 1 1.1`);
            runcmd(entity,`playsound j.slash @a ~${x} ~ ~${z} 1 1.2`);
            runcmd(entity,`playsound j.slash @a ~${x} ~ ~${z} 1 1.4`);
            runcmd(entity,`tp ~${x} ~3 ~${z}`);
          }else {
            runcmd(entity,`event entity @s despawn`);
          }
        break;
        case 'fukuma_explode_start2':
          var x = rand(),
              y = Math.random(),
              z = rand();
          if(x * x + y * y + z * z < 1) {
            x = x*50;
            y = y*50;
            z = z*50;
            runcmd(entity,`particle j:fukuma_kai ~${x} ~${y} ~${z}`);
            runcmd(entity,`playsound j.slash @a ~${x} ~${y} ~${z} 1 1.1`);
            runcmd(entity,`playsound j.slash @a ~${x} ~${y} ~${z} 1 1.2`);
            runcmd(entity,`playsound j.slash @a ~${x} ~${y} ~${z} 1 1.4`);
            runcmd(entity,`tp ~${x} ~${y+3} ~${z}`);
          }else {
            runcmd(entity,`event entity @s despawn`);
          }
        break;
        case 'sukuna_finger':
          var score = getScore(entity,`sukuna_finger`)+1;
          runcmd(entity,`scoreboard players add @s sukuna_finger 1`);
          runcmd(entity,`tellraw @a[r=8] {"rawtext":[{"translate":"text.sukuna.sukuna_finger"},{"text":" (${score+1})"}]}`);
          runcmd(entity,`event entity @s sukuna_finger${score+1}`);
          if(score >= 19){
            entity.addTag(`max_sukuna_finger`);
          }
        break;
        case 'died':
          if((entity.typeId === "rai:sukuna" || entity.typeId === "rai:raichu_jurei" || entity.typeId === "rai:panda_triceratops") && entity.nameTag !== ""){
            runcmd(entity,`kill @a[name="${entity.nameTag}"]`);
          }else if(entity.hasTag(`PlayerName_entity`)){
            var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
            if(entity.hasTag(`tyobuku`)){
              if(!entity.hasTag(`no_tyobuku`)){
                runcmd(entity,`tellraw "${PL}" {"rawtext":[{"text":"§a"},{"translate":"entity.${entity.typeId}.name"},{"translate":"text.tokusa.tyobuku_shikigami"}]}`);
                runcmd(entity,`tag "${PL}" add "${entity.typeId.replace(/^rai:/,'')}"`);
                runcmd(entity,`execute as "${PL}" at @s run function tag/tokusa/${entity.typeId.replace(/^rai:/,'')}`);
              }else {
                runcmd(entity,`tellraw "${PL}" {"rawtext":[{"translate":"text.tokusa.tyobuku_shikigami2"}]}`);
              }
            }else if(entity.hasTag(`tokusa_shikigami`) && !entity.hasTag(`kango_aneitei`)){
              if(entity.typeId === "rai:nue"){
                runcmd(entity,`execute as @a[name="${PL}",tag=summon_nue] run function skill/tokusa/remove_juryoku/nue`);
              }else if(entity.typeId === "rai:gama"){
                runcmd(entity,`execute as @a[name="${PL}",tag=summon_gama] run function skill/tokusa/remove_juryoku/gama`);
              }else if(entity.typeId === "rai:orochi"){
                runcmd(entity,`execute as @a[name="${PL}",tag=summon_orochi] run function skill/tokusa/remove_juryoku/orochi`);
              }else if(entity.typeId === "rai:bansyo"){
                runcmd(entity,`execute as @a[name="${PL}",tag=summon_bansyo] run function skill/tokusa/remove_juryoku/bansyo`);
              }else if(entity.typeId === "rai:makora"){
                runcmd(entity,`execute as @a[name="${PL}",tag=summon_makora] run function skill/tokusa/remove_juryoku/makora`);
              }
              runcmd(entity,`tellraw "${PL}" {"rawtext":[{"text":"§c"},{"translate":"entity.${entity.typeId}.name"},{"translate":"text.tokusa.destroy_shikigami"}]}`);
              if(entity.typeId === "rai:gyokuken"){
                if(entity.hasTag(`gyokuken`)){
                  runcmd(entity,`execute as @a[name="${PL}",tag=summon_gyokuken] run function skill/tokusa/remove_juryoku/gyokuken`);
                  runcmd(entity,`execute as "${PL}" run function tag/tokusa/gyokuken_kon`);
                  runcmd(entity,`event entity @e[tag=gyokuken2,tag="PL_${PL}",family=tokusa_shikigami] PlayerName_tokusa_gyokuken3`);
                }else if(entity.hasTag(`gyokuken2`)){
                  runcmd(entity,`execute as @a[name="${PL}",tag=summon_gyokuken2] run function skill/tokusa/remove_juryoku/gyokuken2`);
                  runcmd(entity,`execute as "${PL}" run function tag/tokusa/gyokuken_kon`);
                  runcmd(entity,`event entity @e[tag=gyokuken,tag="PL_${PL}",family=tokusa_shikigami] PlayerName_tokusa_gyokuken3`);
                }else if(entity.hasTag(`gyokuken3`)){
                  runcmd(entity,`execute as @a[name="${PL}",tag=summon_gyokuken3] run function skill/tokusa/remove_juryoku/gyokuken3`);
                  runcmd(entity,`tag "${PL}" remove gyokuken3`);
                }
              }else{
                runcmd(entity,`tag "${PL}" remove "${entity.typeId.replace(/^rai:/,'')}"`);
              }
            }
          }
        break;
        case 'kill':
          if(entity.hasTag(`tyobuku`) && entity.hasTag(`datto`) && !entity.hasTag(`no_tyobuku`)){
            var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
            runcmd(entity,`tag @s add datto_died`);
            runcmd(entity,`execute unless entity @e[tag="PL_${PL}",tag=datto,tag=!datto_died,type=!player] run tag @s add datto_ok`);
            runcmd(entity,`execute as @s[tag=datto_ok] run tellraw @a[tag=!datto,name="${PL}"] {"rawtext":[{"text":"§a"},{"translate":"entity.${entity.typeId}.name"},{"translate":"text.tokusa.tyobuku_shikigami"}]}`);
            runcmd(entity,`execute as @s[tag=datto_ok] as @a[tag=!datto,name="${PL}"] at @s run function tag/tokusa/datto`);
            runcmd(entity,`execute as @s[tag=datto_ok] run tag "${PL}" add datto`);
          }else if(entity.hasTag(`jurei_soujutsu_jurei`)){
            var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
            runcmd(entity,`execute anchored eyes run particle j:jurei_death ~~~`);
            runcmd(entity,`tellraw "${PL}" {"rawtext":[{"text":"§c"},{"translate":"entity.${entity.typeId}.name"},{"translate":"text.jurei_soujutsu.jurei_died"}]}`);
          }
        break;
        case 'ryoiki_tenkai_test':
          if(entity.nameTag !== ""){
            if(entity.typeId === "rai:fukuma_mizushi"){
              runcmd(entity,`execute unless entity @a[name="${entity.nameTag}",r=64] run event entity @s despawn`);
            }else {
              if(entity.typeId === "rai:kango_aneitei"){
                runcmd(entity,`execute as @a[name="${entity.nameTag}",r=19.5,tag=sneaking,tag=ryoiki_tenkai_set] run function skill/tokusa/ryoiki_sneaking`);
              }
              runcmd(entity,`execute unless entity @a[name="${entity.nameTag}",r=20] run event entity @s despawn`);
              //runcmd(entity,`execute unless entity @e[name="${entity.nameTag}",r=20,family=!ryoiki_tenkai] run event entity @s despawn`);
            }
          }
        break;
        case 'ryoiki_lose':
          runcmd(entity,`tellraw @a[name="${entity.nameTag}"] {"rawtext":[{"translate":"text.ryoiki_tenkai.ryoiki_lose"}]}`);
          ryoiki_tenkai_despawn(entity);
        break;
        //tokusa
        case 'punch':
          var no_selector_owner = "";
          if(!entity.hasTag(`tyobuku`)){
            var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
            if(PL){
              no_selector_owner = `name=!"${PL}",tag=!"PL_${PL}",`;
            }
          }
          runcmd(entity,`tag @s add punch_damage`);
          runcmd(entity,`execute positioned ~~1.6~ positioned ^^^1 run tag @e[${no_selector_owner}family=!damage,tag=!punch_damage,r=5] add damage_target`);
          runcmd(entity,`execute positioned ~~1.6~ positioned ^^^1 run tag @e[tag=tyobuku,tag=!punch_damage,r=5] add damage_target`);
          if(entity.typeId === "rai:gama"){
            runcmd(entity,`execute as @s[scores={juryoku_lv=0}] run damage @e[tag=damage_target] 1 entity_attack entity @s`);
            runcmd(entity,`execute as @s[scores={juryoku_lv=1}] run damage @e[tag=damage_target] 2 entity_attack entity @s`);
            runcmd(entity,`execute as @s[scores={juryoku_lv=2}] run damage @e[tag=damage_target] 3 entity_attack entity @s`);
            runcmd(entity,`execute as @s[scores={juryoku_lv=3..}] run damage @e[tag=damage_target] 4 entity_attack entity @s`);
          }else {
            runcmd(entity,`execute as @s[scores={juryoku_lv=0}] run damage @e[tag=damage_target] 6 entity_attack entity @s`);
            runcmd(entity,`execute as @s[scores={juryoku_lv=1}] run damage @e[tag=damage_target] 8 entity_attack entity @s`);
            runcmd(entity,`execute as @s[scores={juryoku_lv=2}] run damage @e[tag=damage_target] 9 entity_attack entity @s`);
            runcmd(entity,`execute as @s[scores={juryoku_lv=3..}] run damage @e[tag=damage_target] 12 entity_attack entity @s`);
          }
          runcmd(entity,`tag @e remove damage_target`);
          runcmd(entity,`tag @s remove punch_damage`);
        break;
        case 'hikkaki':
          var no_selector_owner = "";
          if(!entity.hasTag(`tyobuku`)){
            var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
            if(PL){
              no_selector_owner = `name=!"${PL}",tag=!"PL_${PL}",`;
            }
          }
          runcmd(entity,`tag @s add punch_damage`);
          runcmd(entity,`execute positioned ~~2~ positioned ^^^2.5 run tag @e[${no_selector_owner}family=!damage,tag=!punch_damage,r=5] add damage_target`);
          runcmd(entity,`execute positioned ~~2~ positioned ^^^2.5 run tag @e[tag=tyobuku,tag=!punch_damage,r=5] add damage_target`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=0}] run damage @e[tag=damage_target] 7 entity_attack entity @s`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=1}] run damage @e[tag=damage_target] 9 entity_attack entity @s`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=2}] run damage @e[tag=damage_target] 11 entity_attack entity @s`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=3..}] run damage @e[tag=damage_target] 14 entity_attack entity @s`);
          runcmd(entity,`tag @e remove damage_target`);
          runcmd(entity,`tag @s remove punch_damage`);
        break;
        case 'gama_bero':
          var no_selector_owner = "";
          if(entity.hasTag(`fushiguro_shikigami`)){
            no_selector_owner = `type=!rai:fushiguro,tag=!fushiguro_shikigami`;
          }else if(!entity.hasTag(`tyobuku`)){
            var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
            if(PL){
              no_selector_owner = `name=!"${PL}",tag=!"PL_${PL}",`;
            }
          }
          if(entity.hasTag(`kango_aneitei`)){
            runcmd(entity,`particle j:gama_bero`);
            runcmd(entity,`tag @e[${no_selector_owner}family=!damage,tag=!gama_bero_damage,r=3.5] add damage_target`);
            runcmd(entity,`tag @e[tag=tyobuku,tag=!gama_bero_damage,r=3.5] add damage_target`);
            runcmd(entity,`scoreboard players add @e[tag=damage_target] no_move 14`);
            runcmd(entity,`tag @e remove damage_target`);
          }else {
            runcmd(entity,`tag @s add gama_bero_damage`);
            runcmd(entity,`execute unless entity @e[tag=damage_target] anchored eyes positioned ^^^5 run tag @e[${no_selector_owner}family=!damage,tag=!gama_bero_damage,r=5,c=1] add damage_target`);
            runcmd(entity,`execute unless entity @e[tag=damage_target] anchored eyes positioned ^^^5 run tag @e[tag=tyobuku,tag=!gama_bero_damage,r=5,c=1] add damage_target`);
            runcmd(entity,`execute as @s[scores={juryoku_lv=0}] run damage @e[tag=damage_target] 1 entity_attack entity @s`);
            runcmd(entity,`execute as @s[scores={juryoku_lv=1}] run damage @e[tag=damage_target] 2 entity_attack entity @s`);
            runcmd(entity,`execute as @s[scores={juryoku_lv=2}] run damage @e[tag=damage_target] 3 entity_attack entity @s`);
            runcmd(entity,`execute as @s[scores={juryoku_lv=3..}] run damage @e[tag=damage_target] 4 entity_attack entity @s`);
            runcmd(entity,`execute as @e[tag=damage_target] at @s run particle j:gama_bero`);
            runcmd(entity,`scoreboard players add @e[tag=damage_target] no_move 15`);
            runcmd(entity,`tag @e remove damage_target`);
            runcmd(entity,`tag @s remove gama_bero_damage`);
          }
        break;
        case 'orochi_ride2':
          if(entity.hasTag(`fushiguro_shikigami_player`)){
            runcmd(entity,`execute as @e[c=1,type=!player,type=!rai:fushiguro,tag=!fushiguro_shikigami,r=4.5,family=!orochi,family=!damage,family=mob,tag=!no_ride_shikigami] run scoreboard players set @s no_move 30`);
            runcmd(entity,`ride @e[c=1,type=!player,type=!rai:fushiguro,tag=!fushiguro_shikigami,r=4.5,family=!orochi,family=!damage,family=mob,tag=!no_ride_shikigami] start_riding @s`);
          }else if(entity.hasTag(`fushiguro_shikigami`)){
            runcmd(entity,`execute as @e[c=1,type=!rai:fushiguro,tag=!fushiguro_shikigami,r=4.5,family=!orochi,family=!damage,family=mob,tag=!no_ride_shikigami] run scoreboard players set @s no_move 30`);
            runcmd(entity,`ride @e[c=1,type=!rai:fushiguro,tag=!fushiguro_shikigami,r=4.5,family=!orochi,family=!damage,family=mob,tag=!no_ride_shikigami] start_riding @s`);
          }else {
            var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
            runcmd(entity,`tag @e[tag="PL_${PL}",r=4.5,tag=tokusa_shikigami,tag=!tyobuku] add no_ride_shikigami`);
            runcmd(entity,`execute as @e[c=1,name=!"${PL}",r=4.5,family=!orochi,family=!damage,family=mob,tag=!no_ride_shikigami] run scoreboard players set @s no_move 30`);
            runcmd(entity,`ride @e[c=1,name=!"${PL}",r=4.5,family=!orochi,family=!damage,family=mob,tag=!no_ride_shikigami] start_riding @s`);
            runcmd(entity,`tag @e[tag="PL_${PL}",tag=tokusa_shikigami,tag=!tyobuku] remove no_ride_shikigami`);
          }
        break;
        case 'makora_attack':
          var no_selector_owner = "";
          if(!entity.hasTag(`tyobuku`)){
            no_selector_owner = `name=!"${entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'')}",`;
          }
          runcmd(entity,`tag @s add punch_damage`);
          runcmd(entity,`execute positioned ~~2.5~ positioned ^^^2.5 run tag @e[${no_selector_owner}family=!damage,tag=!punch_damage,r=5] add damage_target`);
          runcmd(entity,`execute positioned ~~2.5~ positioned ^^^2.5 run tag @e[tag=tyobuku,tag=!punch_damage,r=5] add damage_target`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=0}] run damage @e[tag=damage_target] 20 entity_attack entity @s`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=1}] run damage @e[tag=damage_target] 25 entity_attack entity @s`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=2}] run damage @e[tag=damage_target] 30 entity_attack entity @s`);
          runcmd(entity,`execute as @s[scores={juryoku_lv=3..}] run damage @e[tag=damage_target] 40 entity_attack entity @s`);
          runcmd(entity,`execute positioned ~~2.5~ positioned ^^^2.5 run damage @e[${no_selector_owner}family=jurei,r=5] 1000 entity_attack entity @s`);
          runcmd(entity,`tag @e remove damage_target`);
          runcmd(entity,`tag @s remove punch_damage`);
        break;
        case 'daruma_jurei_fall':
          var no_selector_owner = "type=!rai:daruma_jurei,";
          if(entity.hasTag(`geto_jurei_soujutsu`)){
            no_selector_owner = `type=!rai:student_geto,`;
          }else {
            const PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
            if(PL){
              no_selector_owner = `name=!"${PL}",tag=!"PL_${PL}",`;
            }
          }
          runcmd(entity,`tag @e[${no_selector_owner}r=2] add damage_target`);
          runcmd(entity,`damage @e[tag=damage_target] 15 entity_attack entity @s[scores={juryoku_lv=0}]`);
          runcmd(entity,`damage @e[tag=damage_target] 20 entity_attack entity @s[scores={juryoku_lv=1}]`);
          runcmd(entity,`damage @e[tag=damage_target] 25 entity_attack entity @s[scores={juryoku_lv=2}]`);
          runcmd(entity,`damage @e[tag=damage_target] 30 entity_attack entity @s[scores={juryoku_lv=3..}]`);
          runcmd(entity,`particle minecraft:large_explosion ~2~1~`);
          runcmd(entity,`particle minecraft:large_explosion ~-2~1~`);
          runcmd(entity,`particle minecraft:large_explosion ~~1~2`);
          runcmd(entity,`particle minecraft:large_explosion ~~1~-2`);
          runcmd(entity,`particle minecraft:large_explosion ~1.5~1~1.5`);
          runcmd(entity,`particle minecraft:large_explosion ~1.5~1~-1.5`);
          runcmd(entity,`particle minecraft:large_explosion ~-1.5~1~1.5`);
          runcmd(entity,`particle minecraft:large_explosion ~-1.5~1~-1.5`);
          runcmd(entity,`scoreboard players add @e[tag=damage_target] no_move 5`);
          runcmd(entity,`tag @e remove damage_target`);
          runcmd(entity,`summon rai:block_explode ~~~ 0 0 explode4`);
        break;
        case 'bansyo_fall':
          var no_selector_owner = "";
          if(entity.hasTag(`fushiguro_shikigami`)){
            no_selector_owner = `type=!rai:fushiguro,tag=!fushiguro_shikigami`;
          }else if(!entity.hasTag(`tyobuku`)){
            no_selector_owner = `name=!"${entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'')}",tag=!pvp,`;
          }
          runcmd(entity,`tag @s add punch_damage`);
          var juryoku_lv = getScore(entity,`juryoku_lv`);
          if(entity.hasTag(`kango_aneitei`)){
            runcmd(entity,`tag @e[${no_selector_owner}family=!damage,tag=!punch_damage,r=8] add damage_target`);
            runcmd(entity,`tag @e[tag=tyobuku,tag=!punch_damage,r=8] add damage_target`);
            runcmd(entity,`function skill/tokusa_shikigami/bansyo_fall2`);
            switch (juryoku_lv) {
              case 0:
                runcmd(entity,`damage @e[tag=damage_target] 8 entity_attack`);
                break;
              case 1:
                runcmd(entity,`damage @e[tag=damage_target] 10 entity_attack`);
                break;
              case 2:
                runcmd(entity,`damage @e[tag=damage_target] 12 entity_attack`);
                break;
              case 3:
                runcmd(entity,`damage @e[tag=damage_target] 16 entity_attack`);
                break;
              default:
                break;
            }
            runcmd(entity,`scoreboard players add @e[tag=damage_target] no_move 6`);
            runcmd(entity,`scoreboard players add @e[tag=damage_target] cooltime 6`);
            runcmd(entity,`tag @e[tag=damage_target] add cooltime`);
          }else {
            runcmd(entity,`tag @e[${no_selector_owner}family=!damage,tag=!punch_damage,r=6] add damage_target`);
            runcmd(entity,`tag @e[tag=tyobuku,tag=!punch_damage,r=6] add damage_target`);
            runcmd(entity,`function skill/tokusa_shikigami/bansyo_fall`);
            switch (juryoku_lv) {
              case 0:
                runcmd(entity,`damage @e[tag=damage_target] 5 entity_attack entity @s`);
                break;
              case 1:
                runcmd(entity,`damage @e[tag=damage_target] 6 entity_attack entity @s`);
                break;
              case 2:
                runcmd(entity,`damage @e[tag=damage_target] 8 entity_attack entity @s`);
                break;
              case 3:
                runcmd(entity,`damage @e[tag=damage_target] 10 entity_attack entity @s`);
                break;
              default:
                break;
            }
          }
          runcmd(entity,`damage @e[tag=damage_target] 5 entity_attack entity @s`);
          runcmd(entity,`tag @e remove damage_target`);
          runcmd(entity,`tag @s remove punch_damage`);
        break;
        case 'despawn':
          var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
          if(entity.hasTag(`ryoiki_start`)){
            if(entity.hasTag(`ryoiki_draw`)){
              runcmd(entity,`tellraw @a[name="${entity.nameTag}"] {"rawtext":[{"translate":"text.ryoiki_tenkai.ryoiki_lose"}]}`);
            }
            ryoiki_tenkai_despawn(entity);
          }else if(entity.hasTag(`tyobuku`)){
            return;
          }else if(!entity.hasTag(`kango_aneitei`)){
            if(entity.typeId === "rai:gyokuken"){
              if(entity.hasTag(`gyokuken`)){
                runcmd(entity,`execute as @a[name="${PL}",tag=summon_gyokuken] run function skill/tokusa/remove_juryoku/gyokuken`);
              }else if(entity.hasTag(`gyokuken2`)){
                runcmd(entity,`execute as @a[name="${PL}",tag=summon_gyokuken2] run function skill/tokusa/remove_juryoku/gyokuken2`);
              }else if(entity.hasTag(`gyokuken3`)){
                runcmd(entity,`execute as @a[name="${PL}",tag=summon_gyokuken3] run function skill/tokusa/remove_juryoku/gyokuken3`);
              }
            }else if(entity.typeId === "rai:nue"){
              runcmd(entity,`execute as @a[name="${PL}",tag=summon_nue] run function skill/tokusa/remove_juryoku/nue`);
            }else if(entity.typeId === "rai:gama"){
              runcmd(entity,`execute as @a[name="${PL}",tag=summon_gama] run function skill/tokusa/remove_juryoku/gama`);
            }else if(entity.typeId === "rai:orochi"){
              runcmd(entity,`execute as @a[name="${PL}",tag=summon_orochi] run function skill/tokusa/remove_juryoku/orochi`);
            }else if(entity.typeId === "rai:bansyo"){
              runcmd(entity,`execute as @a[name="${PL}",tag=summon_bansyo] run function skill/tokusa/remove_juryoku/bansyo`);
            }else if(entity.typeId === "rai:makora"){
              runcmd(entity,`execute as @a[name="${PL}",tag=summon_makora] run function skill/tokusa/remove_juryoku/makora`);
            }
          }
        break;
        case 'jurei_soujutsu_despawn':
          var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
          var data = jurei_list.filter(value=>{if(value.id === entity.typeId){return value;}})[0];
          runcmd(entity,`execute rotated as @a[name="${PL}"] run summon rai:particle ~~~ ~ 0 jurei_summon`);
          runcmd(entity,`scoreboard players add @a[name="${PL}"] ${data.score_name} 1`);
          runcmd(entity,`tellraw @a[name="${PL}"] {"rawtext":[{"translate":"text.jurei_soujutsu.set"},{"translate":"text.jurei_soujutsu.modosu"},{"translate":"entity.${data.id}.name"},{"translate":"text.jurei_soujutsu.modosu2"},{"score":{"name":"@a[name=\\"${PL}\\"]","objective":"${data.score_name}"}},{"translate":"text.jurei_soujutsu.count"}]}`);
        break;
        case 'worm_jurei_despawn':
          var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
          //var data = jurei_list.filter(value=>{if(value.id === entity.typeId){return value;}})[0];
          if(entity.hasTag(`worm_jurei_attack`)){
            runcmd(entity,`summon rai:particle ~~~ ~ 0 jurei_summon_2`);
          }else {
            runcmd(entity,`summon rai:particle ~~~ ~ 0 jurei_summon_1`);
          }
          runcmd(entity,`execute as @s[tag=!worm_jurei_despawn] run scoreboard players add @a[name="${PL}"] count_worm 1`);
          runcmd(entity,`tag @s add worm_jurei_despawn`);
        break;
        case 'daruma_jurei_despawn':
          var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
          runcmd(entity,`summon rai:particle ~~~ ~ 0 jurei_summon_1`);
          runcmd(entity,`execute as @s[tag=!daruma_jurei_despawn] run scoreboard players add @a[name="${PL}"] count_daruma 1`);
          runcmd(entity,`tag @s add daruma_jurei_despawn`);
        break;
        case 'squid_jurei_despawn':
          var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
          runcmd(entity,`execute as @s[tag=!squid_jurei_despawn] run scoreboard players add @a[name="${PL}"] count_squid 1`);
          runcmd(entity,`tag @s add squid_jurei_despawn`);
        break;
        case 'kango_aneitei_attack':
          var no_damage_selector = `family=!damage,type=!falling_block,tag=!no_player`;
          if(entity.nameTag !== ""){
            no_damage_selector = no_damage_selector+`,name=!"${entity.nameTag}",tag=!"PL_${entity.nameTag}",tag=!juryoku0`;
          }
          runcmd(entity,`effect @e[r=19.5,${no_damage_selector}] slowness 1 3 true`);
          runcmd(entity,`event entity @a[r=19.5,name=!"${entity.nameTag}"] jump_boost-2`);
        break;
        case 'muryo_kusho_attack':
          var no_damage_selector = `family=!damage,tag=!no_gameplayer,tag=!ryoiki_tenkai_cooltime,tag=!ryoiki_tenkai_set`;
          if(entity.nameTag !== ""){
            no_damage_selector = no_damage_selector+`,name=!"${entity.nameTag}",tag=!"PL_${entity.nameTag}",tag=!juryoku0`;
          }
          runcmd(entity,`tp @e[family=murasaki,r=19.5] @r[r=19.5,type=!item,${no_damage_selector}]`);
          runcmd(entity,`tp @e[type=rai:knockback,tag=aka_set,name="${entity.nameTag}",r=19.5] @r[r=19.5,type=!item,${no_damage_selector}]`);
          runcmd(entity,`execute as @e[type=rai:knockback,tag=aka_set,name="${entity.nameTag}",r=19.5] if entity @e[r=19.5,type=!item,${no_damage_selector}] run tag @s add aka_muryo_kusho`);
          runcmd(entity,`effect @e[r=19.5,${no_damage_selector}] weakness 1 255 true`);
          runcmd(entity,`effect @e[r=19.5,${no_damage_selector}] slowness 1 255 true`);
          runcmd(entity,`effect @e[r=19.5,${no_damage_selector}] mining_fatigue 1 255 true`);
          runcmd(entity,`effect @e[r=19.5,${no_damage_selector}] haste 1 255 true`);
          runcmd(entity,`scoreboard players add @e[r=19.5,${no_damage_selector},family=!jurei] no_move 3`);
          runcmd(entity,`scoreboard players add @e[r=19.5,${no_damage_selector},family=jurei] no_move 2`);
          runcmd(entity,`execute as @e[r=19.5,tag=!in_ryoiki,${no_damage_selector}] run function skill/reset_cooltime`);
          runcmd(entity,`scoreboard players add @e[r=19.5,${no_damage_selector},family=!jurei] cooltime 3`);
          runcmd(entity,`scoreboard players add @e[r=19.5,${no_damage_selector},family=jurei] cooltime 2`);
          runcmd(entity,`tag @e[r=19.5,${no_damage_selector},tag=!cooltime] add cooltime`);
          runcmd(entity,`execute as @e[r=19.5,tag=!in_ryoiki,${no_damage_selector}] run function skill/reset_cooltime2`);
          runcmd(entity,`scoreboard players add @e[r=19.5,${no_damage_selector},family=!jurei] cooltime2 3`);
          runcmd(entity,`scoreboard players add @e[r=19.5,${no_damage_selector},family=jurei] cooltime2 2`);
          runcmd(entity,`tag @e[r=19.5,${no_damage_selector},tag=!cooltime2] add cooltime2`);
          if(!entity.hasTag(`attack_set`)){
            runcmd(entity,`scoreboard players add @e[r=19.5,${no_damage_selector},family=!jurei,tag=!in_ryoiki] no_move 200`);
            runcmd(entity,`scoreboard players add @e[r=19.5,${no_damage_selector},family=jurei,tag=!in_ryoiki] no_move 100`);
            runcmd(entity,`scoreboard players add @e[r=19.5,${no_damage_selector},family=!jurei,tag=!in_ryoiki] cooltime 100`);
            runcmd(entity,`scoreboard players add @e[r=19.5,${no_damage_selector},family=jurei,tag=!in_ryoiki] cooltime 50`);
            runcmd(entity,`scoreboard players add @e[r=19.5,${no_damage_selector},family=!jurei,tag=!in_ryoiki] cooltime2 100`);
            runcmd(entity,`scoreboard players add @e[r=19.5,${no_damage_selector},family=jurei,tag=!in_ryoiki] cooltime2 50`);
            entity.addTag(`attack_set`);
          }
        break;
        case 'no_tyobuku':
          var PL = entity.getTags().filter(function(tag){return tag.match(/^PL_/);})[0]?.replace(/^PL_/,'');
          runcmd(entity,`tellraw "${PL}" {"rawtext":[{"translate":"text.tokusa.tyobuku_shikigami2"}]}`);
        break;
        default:
        break;
      }
    }
  } catch (e) {
  }
});
async function runcmd(entity,cmd){
  if(!Array.isArray(cmd)){
    try {
      entity.runCommandAsync(cmd);
    } catch(e){
    }
  }else{
    try {
      for (let i = 0; i < cmd.length; i++) {
        entity.runCommandAsync(cmd[i]);
      }
    } catch(e){
    }
  }
};