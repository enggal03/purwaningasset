import { system, world } from "@minecraft/server";

world.afterEvents.itemStartUse.subscribe(data => {
  const { source, itemStack } = data;
  if (source.typeId == "minecraft:player" && itemStack.typeId == "morph:evoker_fang") {
    world.playSound("mob.evocation_illager.cast_spell", source.location);
  };
});

world.afterEvents.itemStopUse.subscribe(data => {
  const { source, itemStack, useDuration } = data;
  if (source.typeId == "minecraft:player" && itemStack.typeId == "morph:evoker_fang" && useDuration > 0) {
    source.sendMessage({ rawtext: [{ text: "§7" }, { translate: "chat.mob_item.charge" }, { text: "§r" }]});
  };
});

world.afterEvents.itemCompleteUse.subscribe(data => {
  const { source, itemStack } = data;
  if (source.typeId == "minecraft:player" && itemStack.typeId == "morph:evoker_fang") {
    let y_level = Math.floor(source.location.y);
    for (let i = 0; i < 16; i++) {
      let fangLocation = { x: Math.floor(source.location.x + (i + 1.5) * Math.cos((source.getRotation().y + 90) * (Math.PI / 180))), y: y_level, z: Math.floor(source.location.z + (i + 1.5) * Math.sin((source.getRotation().y + 90) * (Math.PI / 180))) };
      if (source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y, z: fangLocation.z }).typeId != "minecraft:air" && source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y, z: fangLocation.z }).typeId != "minecraft:water" && source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y, z: fangLocation.z }).typeId != "minecraft:lava") {
        if (source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y + 1, z: fangLocation.z }).typeId != "minecraft:air" && source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y + 1, z: fangLocation.z }).typeId != "minecraft:water" && source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y + 1, z: fangLocation.z }).typeId != "minecraft:lava") {
          if (source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y + 2, z: fangLocation.z }).typeId != "minecraft:air" && source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y + 2, z: fangLocation.z }).typeId != "minecraft:water" && source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y + 2, z: fangLocation.z }).typeId != "minecraft:lava") { break; }
          else { y_level = y_level + 2 };
        } else { y_level = y_level + 1 };
      } else if (source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y - 1, z: fangLocation.z }).typeId == "minecraft:air" || source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y - 1, z: fangLocation.z }).typeId == "minecraft:water" || source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y - 1, z: fangLocation.z }).typeId == "minecraft:lava") {
        if (source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y - 2, z: fangLocation.z }).typeId == "minecraft:air" || source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y - 2, z: fangLocation.z }).typeId == "minecraft:water" || source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y - 2, z: fangLocation.z }).typeId == "minecraft:lava") {
          if (source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y - 3, z: fangLocation.z }).typeId == "minecraft:air" || source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y - 3, z: fangLocation.z }).typeId == "minecraft:water" || source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y - 3, z: fangLocation.z }).typeId == "minecraft:lava") {
            if (source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y - 4, z: fangLocation.z }).typeId == "minecraft:air" || source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y - 4, z: fangLocation.z }).typeId == "minecraft:water" || source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y - 4, z: fangLocation.z }).typeId == "minecraft:lava") {
              if (source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y - 5, z: fangLocation.z }).typeId == "minecraft:air" || source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y - 5, z: fangLocation.z }).typeId == "minecraft:water" || source.dimension.getBlock({ x: fangLocation.x, y: fangLocation.y - 5, z: fangLocation.z }).typeId == "minecraft:lava") { break; }
              else { y_level = y_level - 4 };
            } else { y_level = y_level - 3 };
          } else { y_level = y_level - 2 };
        } else { y_level = y_level - 1 };
      };
      fangLocation.y = y_level;
      system.runTimeout(() => {
        source.runCommand(`summon minecraft:evocation_fang ${fangLocation.x} ${fangLocation.y} ${fangLocation.z}`);
      }, i);
    };
  };
});