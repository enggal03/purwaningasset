import "morphingBracelet.js";
import "eventManager.js";
import "mobSounds.js";
import "mobItems.js";
import "onHit.js";
import "foodEaten.js";
import "projectileTeleportation.js";
import "storeNectar.js";
// import "witchPotion.js"; Currently disabled due to a change in a minecraft update that made this ability not possible anymore :')
import "frogAttack.js";
import "evokerFang.js";
import "ohioSnowball.js";

import { system, world, Player } from "@minecraft/server";

system.beforeEvents.watchdogTerminate.subscribe(data => { data.cancel = true; });

system.runInterval(() => {
  for (const player of world.getPlayers()) {
    player.triggerEvent("morph:on_tick");
    if (player.getComponent("minecraft:variant").value != 0) {
      if (player.nameTag != "") { player.nameTag = ""; };
    } else { if (player.nameTag != player.name) { player.nameTag = player.name; }; };
  };
  for (const player of world.getPlayers({gameMode: "adventure"})) { if (player.gameMode != "adventure") { player.gameMode = "adventure"; player.runCommand("ability @s mayfly false"); }; };
  for (const player of world.getPlayers({gameMode: "creative"})) { if (player.gameMode != "creative") { player.gameMode = "creative"; player.runCommand("ability @s mayfly true"); }; };
  for (const player of world.getPlayers({gameMode: "spectator"})) { if (player.gameMode != "spectator") { player.gameMode = "spectator"; player.runCommand("ability @s mayfly true"); }; };
  for (const player of world.getPlayers({gameMode: "survival"})) { if (player.gameMode != "survival") { player.gameMode = "survival"; player.runCommand("ability @s mayfly false"); }; };
});

Player.prototype.getColor = function() {
  for (let i = 0; i < this.getTags().length; i++) {
    if (this.getTags()[i].startsWith("morph:color.")) {
      return Number(this.getTags()[i].substring(12));
    };
  };
  return 0;
};

Player.prototype.getColor2 = function() {
  for (let i = 0; i < this.getTags().length; i++) {
    if (this.getTags()[i].startsWith("morph:color2.")) {
      return Number(this.getTags()[i].substring(13));
    };
  };
  return 0;
};