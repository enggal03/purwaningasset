import { world, ItemStack, ItemLockMode } from '@minecraft/server';

world.afterEvents.dataDrivenEntityTriggerEvent.subscribe(data => {
  const { entity, id } = data;

  if (entity.typeId == "minecraft:player") {
    if (id == "morph:post_morph") { removeMobItems(entity); };

    if (id == "morph:skeleton") { addMobItem(entity, "minecraft:bow"); };
    if (id == "morph:enderman") { addMobItem(entity, "morph:teleportation"); };
    if (id == "morph:zombified_piglin") { addMobItem(entity, "minecraft:golden_sword"); };
    if (id == "morph:wither_skeleton") { addMobItem(entity, "minecraft:stone_sword"); };
    if (id == "morph:snow_golem") { addMobItem(entity, "morph:snow_golem_ball"); };
    if (id == "morph:sheared_snow_golem") { addMobItem(entity, "morph:snow_golem_ball"); };
    if (id == "morph:blaze") { addMobItem(entity, "morph:blaze_fireball"); };
    if (id == "morph:piglin") { addMobItem(entity, "minecraft:golden_sword"); };
    if (id == "morph:stray") { addMobItem(entity, "minecraft:bow"); };
    if (id == "morph:vindicator") { addMobItem(entity, "minecraft:iron_axe"); };
    if (id == "morph:piglin_brute") { addMobItem(entity, "minecraft:golden_axe"); };
    if (id == "morph:creamy_llama") { addMobItem(entity, "morph:llama_spit"); };
    if (id == "morph:baby_creamy_llama") { addMobItem(entity, "morph:llama_spit"); };
    if (id == "morph:white_llama") { addMobItem(entity, "morph:llama_spit"); };
    if (id == "morph:baby_white_llama") { addMobItem(entity, "morph:llama_spit"); };
    if (id == "morph:brown_llama") { addMobItem(entity, "morph:llama_spit"); };
    if (id == "morph:baby_brown_llama") { addMobItem(entity, "morph:llama_spit"); };
    if (id == "morph:gray_llama") { addMobItem(entity, "morph:llama_spit"); };
    if (id == "morph:baby_gray_llama") { addMobItem(entity, "morph:llama_spit"); };
    if (id == "morph:wither") { addMobItem(entity, "morph:wither_skull"); addMobItem(entity, "morph:wither_skull_dangerous"); };
    if (id == "morph:pillager") { addMobItem(entity, "minecraft:crossbow"); };
    if (id == "morph:vex") { addMobItem(entity, "minecraft:iron_sword"); };
    // if (id == "morph:witch") { addMobItems(entity, "potion.21, splash_potion.23"); };
    if (id == "morph:ghast") { addMobItem(entity, "morph:ghast_fireball"); };
    if (id == "morph:evoker") { addMobItem(entity, "morph:evoker_fang"); };
    if (id == "morph:creamy_trader_llama") { addMobItem(entity, "morph:llama_spit"); };
    if (id == "morph:baby_creamy_trader_llama") { addMobItem(entity, "morph:llama_spit"); };
    if (id == "morph:white_trader_llama") { addMobItem(entity, "morph:llama_spit"); };
    if (id == "morph:baby_white_trader_llama") { addMobItem(entity, "morph:llama_spit"); };
    if (id == "morph:brown_trader_llama") { addMobItem(entity, "morph:llama_spit"); };
    if (id == "morph:baby_brown_trader_llama") { addMobItem(entity, "morph:llama_spit"); };
    if (id == "morph:gray_trader_llama") { addMobItem(entity, "morph:llama_spit"); };
    if (id == "morph:baby_gray_trader_llama") { addMobItem(entity, "morph:llama_spit"); };
    
    if (id == "morph:skeleton_become_stray_event") { addMobItem(entity, "minecraft:bow"); };
    if (id == "morph:pig_become_zombie" && !entity.getComponent('minecraft:is_baby')) { addMobItem(entity, "minecraft:golden_sword"); };
    // if (id == "morph:villager_become_witch") { addMobItems(entity, "potion.21,splash_potion.23"); };
    if (id == "morph:piglin_become_zombie_event" && !entity.getComponent('minecraft:is_baby')) { addMobItem(entity, "minecraft:golden_sword"); };
    if (id == "morph:piglin_brute_become_zombie_event") { addMobItem(entity, "minecraft:golden_axe"); };
  };
});

function addMobItem(entity, item) {
  let itemStack = new ItemStack(item, 1);
  itemStack.setLore(["Morph Addon"]);
  itemStack.lockMode = ItemLockMode.inventory;
  itemStack.keepOnDeath = true;
  entity.getComponent("minecraft:inventory").container.addItem(itemStack);
};

function removeMobItems(entity) {
  for (let slot = 0; slot < entity.getComponent("minecraft:inventory").container.size; slot++) {
    let item = entity.getComponent("minecraft:inventory").container.getItem(slot);
    try {
      if (item.getLore().includes("Morph Addon")) {
        entity.getComponent("minecraft:inventory").container.setItem(slot, undefined);
      };
    } catch {};
  };
};