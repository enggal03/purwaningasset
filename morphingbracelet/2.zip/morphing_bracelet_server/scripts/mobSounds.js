import { world } from "@minecraft/server";
import { mobSounds } from "morphables.js";

world.afterEvents.entityHurt.subscribe(data => {
  const { hurtEntity, damageSource } = data;
  if (hurtEntity.typeId == "minecraft:player") {
    for (let i = 0; i < mobSounds.length; i++) {
      if (mobSounds[i].variant == hurtEntity.getComponent("minecraft:variant").value) {
        let sound = {
          pitch: (Array.isArray(mobSounds[i].pitch) ? range(mobSounds[i].pitch): mobSounds[i].pitch) + (hurtEntity.getComponent("minecraft:is_baby") ? 0.5: 0),
          volume: mobSounds[i].volume
        };
        if (hurtEntity.getComponent("minecraft:health").currentValue > 0) {
          if (mobSounds[i].hurt != undefined) {
            if (typeof mobSounds[i].hurt == "object") {
              if (Array.isArray(mobSounds[i].hurt)) {
                for (let n = 0; n < mobSounds[i].hurt.length; n++) {
                  if (mobSounds[i].hurt[n].pitch != undefined) { sound.pitch = (Array.isArray(mobSounds[i].hurt[n].pitch) ? range(mobSounds[i].hurt[n].pitch): mobSounds[i].hurt[n].pitch) + (hurtEntity.getComponent("minecraft:is_baby") ? 0.5: 0); };
                  if (mobSounds[i].hurt[n].volume != undefined) { sound.volume = mobSounds[i].hurt[n].volume; };
                  if (mobSounds[i].hurt[n].condition == undefined ? true: eval(mobSounds[i].hurt[n].condition.replace(new RegExp("\\bentity\\b","g"), "hurtEntity"))) {
                    world.playSound(mobSounds[i].hurt[n].sound, hurtEntity.location, sound);
                  };
                };
              } else {
                if (mobSounds[i].hurt.pitch != undefined) { sound.pitch = (Array.isArray(mobSounds[i].hurt.pitch) ? range(mobSounds[i].hurt.pitch): mobSounds[i].hurt.pitch) + (hurtEntity.getComponent("minecraft:is_baby") ? 0.5: 0); };
                if (mobSounds[i].hurt.volume != undefined) { sound.volume = mobSounds[i].hurt.volume; };
                if (mobSounds[i].hurt.condition == undefined ? true: eval(mobSounds[i].hurt.condition.replace(new RegExp("\\bentity\\b","g"), "hurtEntity"))) {
                  world.playSound(mobSounds[i].hurt.sound, hurtEntity.location, sound);
                };
              };
            } else { world.playSound(mobSounds[i].hurt, hurtEntity.location, sound); };
          } else { world.playSound("game.player.hurt", hurtEntity.location, sound); };
        };
      };
    };
  };
});

world.afterEvents.entityDie.subscribe(data => {
  const { deadEntity, damageSource } = data;
  if (deadEntity.typeId == "minecraft:player") {
    for (let i = 0; i < mobSounds.length; i++) {
      if (mobSounds[i].variant == deadEntity.getComponent("minecraft:variant").value) {
        let sound = {
          pitch: (Array.isArray(mobSounds[i].pitch) ? range(mobSounds[i].pitch): mobSounds[i].pitch) + (deadEntity.getComponent("minecraft:is_baby") ? 0.5: 0),
          volume: mobSounds[i].volume
        };
        if (mobSounds[i].death != undefined) {
          if (typeof mobSounds[i].death == "object") {
            if (Array.isArray(mobSounds[i].death)) {
              for (let n = 0; n < mobSounds[i].death.length; n++) {
                if (mobSounds[i].death[n].pitch != undefined) { sound.pitch = (Array.isArray(mobSounds[i].death[n].pitch) ? range(mobSounds[i].death[n].pitch): mobSounds[i].death[n].pitch) + (deadEntity.getComponent("minecraft:is_baby") ? 0.5: 0); };
                if (mobSounds[i].death[n].volume != undefined) { sound.volume = mobSounds[i].death[n].volume; };
                if (mobSounds[i].death[n].condition == undefined ? true: eval(mobSounds[i].death[n].condition.replace(new RegExp("\\bentity\\b","g"), "deadEntity"))) {
                  world.playSound(mobSounds[i].death[n].sound, deadEntity.location, sound);
                };
              };
            } else {
              if (mobSounds[i].death.pitch != undefined) { sound.pitch = (Array.isArray(mobSounds[i].death.pitch) ? range(mobSounds[i].death.pitch): mobSounds[i].death.pitch) + (deadEntity.getComponent("minecraft:is_baby") ? 0.5: 0); };
              if (mobSounds[i].death.volume != undefined) { sound.volume = mobSounds[i].death.volume; };
              if (mobSounds[i].death.condition == undefined ? true: eval(mobSounds[i].death.condition.replace(new RegExp("\\bentity\\b","g"), "deadEntity"))) {
                world.playSound(mobSounds[i].death.sound, deadEntity.location, sound);
              };
            };
          } else { world.playSound(mobSounds[i].death, deadEntity.location, sound); };
        } else { world.playSound("game.player.die", deadEntity.location, sound); };
      };
    };
  };
});

function range(array) {
  return parseFloat((Math.random() * (array[1] - array[0]) + array[0]).toFixed(2));
};