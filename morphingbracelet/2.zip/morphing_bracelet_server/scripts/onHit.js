import { system, world } from "@minecraft/server";

world.afterEvents.entityHitEntity.subscribe(data => {
  const { damagingEntity, hitEntity } = data;
  if (damagingEntity.typeId == "minecraft:player" && !hitEntity.hasTag("damaged")) {
    damagedTag(hitEntity);
    if (damagingEntity.getComponent("minecraft:variant").value == 15) { hitEntity.addEffect("wither", 10 * 20); };
    if (damagingEntity.getComponent("minecraft:variant").value == 19) { hitEntity.addEffect("hunger", 30 * 20); };
    if (damagingEntity.getComponent("minecraft:variant").value == 23) { system.run(() => { hitEntity.applyImpulse({ x: 0, y: hitEntity.getVelocity().y, z: 0 })}); };
    if (damagingEntity.getComponent("minecraft:variant").value == 33) { hitEntity.addEffect("poison", 7 * 20); };
    if (damagingEntity.getComponent("minecraft:variant").value == 40 && damagingEntity.getComponent("minecraft:mark_variant").value != 1) {
      hitEntity.addEffect("poison", 10 * 20);
      if (damagingEntity.gameMode != "creative") {
        damagingEntity.triggerEvent("morph:bee_countdown_to_perish");
        world.playSound("mob.bee.sting", damagingEntity.location);
      };
    };
  };
});

function damagedTag(entity) {
  entity.addTag("damaged");
  system.runTimeout(() => {
    try { entity.removeTag("damaged"); } catch {};
  }, 9);
};