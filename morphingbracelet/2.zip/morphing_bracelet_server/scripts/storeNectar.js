import { system, world } from "@minecraft/server";

system.runInterval(() => {
  for (const player of world.getPlayers()) {
    try {
      const block = player.getBlockFromViewDirection({ includeLiquidBlocks: false, includePassableBlocks: true, maxDistance: 4 }).block;
      if ((player.getComponent("minecraft:variant").value == 40 && player.getComponent("minecraft:is_charged")) && (block && (block.typeId == "minecraft:bee_nest" || block.typeId == "minecraft:beehive")) && player.isSneaking) {
        player.triggerEvent("morph:bee_collect_nectar");
        block.setPermutation(block.permutation.withState("honey_level", block.permutation.getState("honey_level") < 5 ? block.permutation.getState("honey_level") + 1 : block.permutation.getState("honey_level") + 0));
        world.playSound("block.beehive.enter", block.location);
      };
    } catch {};
  };
});