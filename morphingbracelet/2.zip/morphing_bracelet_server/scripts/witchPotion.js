import { system, world } from "@minecraft/server";

let potions = [
  { id: 21, potion: "heal" },
  { id: 12, potion: "fireResistance" },
  { id: 19, potion: "waterBreathing" },
  { id: 14, potion: "moveSpeed" }
];
let splashPotions = [
  { id: 23, potion: "harm" },
  { id: 25, potion: "poison" },
  { id: 17, potion: "moveSlowdown" },
  { id: 34, potion: "weakness" }
];
let potionDuration = {};
let splashPotionDuration = {};

world.events.itemUse.subscribe(data => {
  const { item, source } = data;
  if (source.typeId == "minecraft:player" && source.getComponent("minecraft:variant").value == 47) {
    if (item.typeId == "minecraft:splash_potion" && item.getLore().includes("Morph Addon")) {
      system.run(() => {
        source.getComponent("minecraft:inventory").container.setItem(source.selectedSlot, item);
        splashPotionDuration[source.name] = 67;
      });
    };
  };
});

world.events.itemCompleteCharge.subscribe(data => {
  const { itemStack, source } = data;
  if (source.typeId == "minecraft:player" && source.getComponent("minecraft:variant").value == 47) {
    if (itemStack.typeId == "minecraft:potion" && itemStack.getLore().includes("Morph Addon")) {
      if (source.gameMode == "creative") {
        let glassBottle = null;
        for (let slot = 0; slot < source.getComponent("minecraft:inventory").container.size; slot++) {
          let item = source.getComponent("minecraft:inventory").container.getItem(slot);
          if (item == null) { glassBottle = slot; break; };
        };
        for (let slot = 0; slot < source.getComponent("minecraft:inventory").container.size; slot++) {
          let item = source.getComponent("minecraft:inventory").container.getItem(slot);
          if (item != null && item.typeId == "minecraft:glass_bottle") { glassBottle = slot; break; };
        };
        system.run(() => {
          if (glassBottle != null) {
            if (source.getComponent("minecraft:inventory").container.getItem(glassBottle) != null) {
              let amount = source.getComponent("minecraft:inventory").container.getItem(glassBottle).amount;
              source.runCommandAsync(`replaceitem entity @s ${glassBottle < 9 ? `slot.hotbar ${glassBottle}` : `slot.inventory ${glassBottle - 9}`} ${amount <= 1 ? "air" : `minecraft:glass_bottle ${amount - 1}`}`);
              system.runTimeout(() => {
                source.getComponent("minecraft:inventory").container.setItem(source.selectedSlot, itemStack);
                potionDuration[source.name] = 67;
              }, 1);
            };
          } else {
            source.runCommandAsync('execute anchored eyes run kill @e[type=item,r=0.1,c=1]');
            system.run(() => {potionDuration[source.name] = 67});
          };
        });
      } else {
        system.run(() => {
          source.getComponent("minecraft:inventory").container.setItem(source.selectedSlot, itemStack);
          potionDuration[source.name] = 67;
        });
      };
    };
  };
});

world.events.beforeItemUse.subscribe(data => {
  const { item, source } = data;
  if (source.typeId == "minecraft:player" && source.getComponent("minecraft:variant").value == 47) {
    if (item.typeId == "morph:unusable_potion" && item.getLore().includes("Morph Addon") && potionDuration[source.name] > 0) {
      let message = { rawtext: [{ text: "§7" }, { translate: "chat.mob_item.duration", with: [ `${Math.round((potionDuration[source.name] / 20) * 10) / 10}` ] }, { text: "§r" }] };
      source.sendMessage(message);
    };
    if (item.typeId == "morph:unusable_splash_potion" && item.getLore().includes("Morph Addon") && splashPotionDuration[source.name] > 0) {
      let message = { rawtext: [{ text: "§7" }, { translate: "chat.mob_item.duration", with: [ `${Math.round((splashPotionDuration[source.name] / 20) * 10) / 10}` ] }, { text: "§r" }] };
      source.sendMessage(message);
    };

    if (source.isSneaking && item.typeId == "minecraft:potion" && item.getLore().includes("Morph Addon")) {
      data.cancel = true;
      let nextItem = source.getComponent("minecraft:inventory").container.getItem(source.selectedSlot);
      nextItem.data = potions[potions.map(potion => potion.id).indexOf(item.data) == Object.keys(potions).length - 1 ? 0 : potions.map(potion => potion.id).indexOf(item.data) + 1].id;
      source.getComponent("minecraft:inventory").container.setItem(source.selectedSlot, nextItem);
      source.runCommandAsync(`titleraw @s actionbar {"rawtext":[{"text":"Selected: "},{"translate":"potion.${potions[potions.map(potion => potion.id).indexOf(nextItem.data) - 1 == Object.keys(potions).length - 1 ? 0 : potions.map(potion => potion.id).indexOf(nextItem.data)].potion}.name"}]}`);
    };
    if (source.isSneaking && item.typeId == "minecraft:splash_potion" && item.getLore().includes("Morph Addon")) {
      data.cancel = true;
      let nextItem = source.getComponent("minecraft:inventory").container.getItem(source.selectedSlot);
      nextItem.data = splashPotions[splashPotions.map(splashPotion => splashPotion.id).indexOf(item.data) == Object.keys(splashPotions).length - 1 ? 0 : splashPotions.map(splashPotion => splashPotion.id).indexOf(item.data) + 1].id;
      source.getComponent("minecraft:inventory").container.setItem(source.selectedSlot, nextItem);
      source.runCommandAsync(`titleraw @s actionbar {"rawtext":[{"text":"Selected: "},{"translate":"potion.${splashPotions[splashPotions.map(splashPotion => splashPotion.id).indexOf(nextItem.data) - 1 == Object.keys(splashPotions).length - 1 ? 0 : splashPotions.map(splashPotion => splashPotion.id).indexOf(nextItem.data)].potion}.splash.name"}]}`);
    };
  };
});

system.runInterval(() => {
  for (let player of world.getPlayers()) {
    if (player.getComponent("minecraft:variant").value == 47) {
      if (!Object.keys(potionDuration).includes(player.name)) { potionDuration[player.name] = 0; };
      if (!Object.keys(splashPotionDuration).includes(player.name)) { splashPotionDuration[player.name] = 0; };

      if (potionDuration[player.name] > 0) {
        for (let slot = 0; slot < player.getComponent("minecraft:inventory").container.size; slot++) {
          let item = player.getComponent("minecraft:inventory").container.getItem(slot);
          try {
            if (item.typeId == "minecraft:potion" && item.getLore().includes("Morph Addon")) {
              let potionId = item.data;
              player.runCommandAsync(`replaceitem entity @s ${slot < 9 ? `slot.hotbar ${slot}` : `slot.inventory ${slot - 9}`} morph:unusable_potion 1 0 {"item_lock":{"mode": "lock_in_inventory"},"keep_on_death":{}}`);
              system.runTimeout(() => {
                let morphItem = player.getComponent("minecraft:inventory").container.getItem(slot);
                morphItem.setLore([`§r§7Potion ID: ${potionId}§r`,"Morph Addon"]);
                player.getComponent("minecraft:inventory").container.setItem(slot, morphItem);
              }, 1);
            };
          } catch {};
        };
      };
      if (potionDuration[player.name] <= 0) {
        for (let slot = 0; slot < player.getComponent("minecraft:inventory").container.size; slot++) {
          let item = player.getComponent("minecraft:inventory").container.getItem(slot);
          try {
            if (item.typeId == "morph:unusable_potion" && item.getLore().includes("Morph Addon")) {
              let potionId = item.getLore()[0].slice("§r§7Potion ID: ".length, item.getLore()[0].length - "§r".length);
              player.runCommandAsync(`replaceitem entity @s ${slot < 9 ? `slot.hotbar ${slot}` : `slot.inventory ${slot - 9}`} minecraft:potion 1 ${potionId} {"item_lock":{"mode": "lock_in_inventory"},"keep_on_death":{}}`);
              system.runTimeout(() => {
                let morphItem = player.getComponent("minecraft:inventory").container.getItem(slot);
                morphItem.setLore(["Morph Addon"]);
                player.getComponent("minecraft:inventory").container.setItem(slot, morphItem);
              }, 1);
            };
          } catch {};
        };
      };
      if (splashPotionDuration[player.name] > 0) {
        for (let slot = 0; slot < player.getComponent("minecraft:inventory").container.size; slot++) {
          let item = player.getComponent("minecraft:inventory").container.getItem(slot);
          try {
            if (item.typeId == "minecraft:splash_potion" && item.getLore().includes("Morph Addon")) {
              let potionId = item.data;
              player.runCommandAsync(`replaceitem entity @s ${slot < 9 ? `slot.hotbar ${slot}` : `slot.inventory ${slot - 9}`} morph:unusable_splash_potion 1 0 {"item_lock":{"mode": "lock_in_inventory"},"keep_on_death":{}}`);
              system.runTimeout(() => {
                let morphItem = player.getComponent("minecraft:inventory").container.getItem(slot);
                morphItem.setLore([`§r§7Potion ID: ${potionId}§r`,"Morph Addon"]);
                player.getComponent("minecraft:inventory").container.setItem(slot, morphItem);
              }, 1);
            };
          } catch {};
        };
      };
      if (splashPotionDuration[player.name] <= 0) {
        for (let slot = 0; slot < player.getComponent("minecraft:inventory").container.size; slot++) {
          let item = player.getComponent("minecraft:inventory").container.getItem(slot);
          try {
            if (item.typeId == "morph:unusable_splash_potion" && item.getLore().includes("Morph Addon")) {
              let potionId = item.getLore()[0].slice("§r§7Potion ID: ".length, item.getLore()[0].length - "§r".length);
              player.runCommandAsync(`replaceitem entity @s ${slot < 9 ? `slot.hotbar ${slot}` : `slot.inventory ${slot - 9}`} minecraft:splash_potion 1 ${potionId} {"item_lock":{"mode": "lock_in_inventory"},"keep_on_death":{}}`);
              system.runTimeout(() => {
                let morphItem = player.getComponent("minecraft:inventory").container.getItem(slot);
                morphItem.setLore(["Morph Addon"]);
                player.getComponent("minecraft:inventory").container.setItem(slot, morphItem);
              }, 1);
            };
          } catch {};
        };
      };
    };
    if (player.getComponent("minecraft:variant").value != 47) {
      if (Object.keys(potionDuration).includes(player.name)) { delete potionDuration[player.name]; };
      if (Object.keys(splashPotionDuration).includes(player.name)) { delete splashPotionDuration[player.name]; };
    };
  };
  for (let i = 0; i < Object.keys(potionDuration).length; i++) {
    if (potionDuration[Object.keys(potionDuration)[i]] > 0) {
      potionDuration[Object.keys(potionDuration)[i]] = potionDuration[Object.keys(potionDuration)[i]] - 1;
    };
  };
  for (let i = 0; i < Object.keys(splashPotionDuration).length; i++) {
    if (splashPotionDuration[Object.keys(splashPotionDuration)[i]] > 0) {
      splashPotionDuration[Object.keys(splashPotionDuration)[i]] = splashPotionDuration[Object.keys(splashPotionDuration)[i]] - 1;
    };
  };
});