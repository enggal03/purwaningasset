import * as module from 'mojang-minecraft';
var entidades = [];
var inside = ["minecraft:air", "minecraft:water", "minecraft:snow_layer", "minecraft:web", "minecraft:tallgrass" ];
var blackList = ["composter", "snow_layer", "crafting_table", "loom", "cactus", "sand", "unpowered_comparator", "end_rod", "lightning_rod", "unpowered_repeater", "powered_comparator", "powered_comparator", "monster_egg", "undyed_shulker_box", "trapped_chest", "tnt", "stonecutter_block", "stonecutter", "soul_campfire", "smoker", "dropper", "dispenser", "skull", "chest", "barrel", "shulker_box", "furnace", "lit_blast_furnace", "lit_smoker", "bed", "blast_furnace", "anvil", "beacon", "bell", "brewing_stand", "camera", "campfire", "ender_chest", "hopper", "jukebox", "redstone_wire", "mob_spawner", "glow_frame", "frame", "netherite_block", "gravel", "cauldron", "scaffolding", "lantern", "soul_lantern", "lectern", "torch", "soul_torch", "sea_pickle", "lever", "cartography_table", "fletching_table", "smithing_table", "tripwire_hook", "wall_banner", "redstone_torch", "standing_banner"];
module.World.events.entityCreate.subscribe((Data) => {
    if (Data.entity.id == "add:impacted_block") {
        entidades.push(Data.entity);
    }
});

function listaNegra(input, filter) {
    if ((typeof(input) == typeof("")) && (typeof(filter) == typeof([]))) {
        if (filter.length > 0) {
            for (var c = 0; c < filter.length; c++) {
                if (filter[c] == input) {
                    return true
                    break;
                } else if ((c == (filter.length - 1)) && (filter[c] != input)) {
                    return false;
                }
            }
        } else {
            return `Unexpected empty Array!`;
        }
    } else {
        return `Invalid Parameters!`;
    }
}

function EXPLOSION(dimension, expData) {
    var bloques = expData.impactedBlocks;
    var sLoc = expData.source.location;
    if(bloques.length > 1){
    for (var i =0; i< bloques.length; i++) {
        let bloque = dimension.getBlock(new module.BlockLocation(bloques[i].x, bloques[i].y, bloques[i].z));
        let esteBloque = bloque.permutation;
        let names = dimension.getBlock(new module.BlockLocation(bloques[i].x, bloques[i].y, bloques[i].z)).id.split(":")[1];
        let tag = `+${names}`;
        if (listaNegra(names, blackList) == false) {
            module.Commands.run(`setblock ${bloques[i].x} ${bloques[i].y} ${bloques[i].z} air 0 replace`, dimension)
            module.Commands.run(`summon add:impacted_block ${tag} ${bloques[i].x} ${bloques[i].y} ${bloques[i].z}`, dimension);
            let inThese = dimension.getEntitiesAtBlockLocation(new module.BlockLocation(bloques[i].x, bloques[i].y, bloques[i].z));
            if (inThese.length > 0) {
                for (var c in inThese) {
                    if ((inThese[c].id == "add:impacted_block") && (inThese[c].nameTag == tag)) {
                        Object.defineProperty(inThese[c], 'estados', {
                            value: esteBloque,
                            writable: true,
                            configurable: true
                        });
                        Object.defineProperty(inThese[c], 'dimension', {
                            value: dimension,
                            writable: true,
                            configurable: true
                        });
                    }
                }
            }
        }
    }
    dimension.spawnEntity("add:push_block", new module.BlockLocation(Math.floor(sLoc.x), Math.floor(sLoc.y - 3), Math.floor(sLoc.z)));
    }
}

module.World.events.explosion.subscribe((expData) => {
    EXPLOSION(expData.dimension, expData);
})

module.World.events.tick.subscribe(() => {
    try {
        if (entidades.length > 0) {
            for (var i in entidades) {
                try {
                    entidades[i].id;
                } catch (error) {
                    entidades.splice(entidades.indexOf(entidades[i]), 1)
                }
            }
        }
    } catch (error) {}

    try {
        if (entidades.length > 0) {
            for (var d = 0; d < entidades.length; d++) {
                 if (entidades[d].nameTag.startsWith("+")) {
                	if((entidades[d].getComponent("minecraft:strength") !== undefined) && (entidades[d].estados !== undefined) && (entidades[d].dimension !== undefined)){
                	  if(entidades[d].getComponent("minecraft:strength").value == 2){
                        let eX = Math.floor(entidades[d].location.x);
                        let eY = Math.floor(entidades[d].location.y);
                        let eZ = Math.floor(entidades[d].location.z);
                        let bloques = entidades[d].dimension.getBlock(new module.BlockLocation(eX, eY, eZ));
                        if (listaNegra(bloques.id,inside) == true) {
                            try {
                                bloques.setPermutation(entidades[d].estados);
                                entidades.splice(entidades.indexOf(entidades[d]), 1);
                            } catch (error) {}
                        }
                      }
                    }
                }else {}
            }
        }
    } catch (error) {}

})